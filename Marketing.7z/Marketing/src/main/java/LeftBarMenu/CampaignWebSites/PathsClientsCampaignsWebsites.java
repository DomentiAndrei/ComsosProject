package LeftBarMenu.CampaignWebSites;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TCL.Marketing.Boss;

public class PathsClientsCampaignsWebsites extends Boss{

    WebDriver driver;

    @FindBy(xpath  = "//span[contains(text(),'Campaign Websites')]")
    WebElement CampaignsWebsites;
    
    @FindBy(xpath  = "//span[contains(text(),'Clients')]")
    WebElement Clients;

    @FindBy(xpath  = "//span[contains(text(),'Campaigns')]")
    WebElement Campaigns;

    @FindBy(xpath  = "//body/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/nb-sidebar[1]/div[1]/div[1]/nb-menu[1]/ul[1]/li[3]/ul[1]/li[3]/a[1]")
    WebElement Websites;

    public PathsClientsCampaignsWebsites(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }
    
    public void clickCampaignsWebsites() {
    	CampaignsWebsites.click();
    	log.info("CampaignsWebsites opened");
    }

    public void clickClients() {
        Clients.click();
    }

    public void clickCampaigns() {
        Campaigns.click();
    }

    public void clickWebsites() {
        Websites.click();
        log.info("Websites opened");
    }
}
