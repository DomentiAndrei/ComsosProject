package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;
import DataBase.CheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep.DeleteQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep;
import DataBase.CheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep.InsertQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewardsCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStepTest extends Boss { // 9649 nr 4

	InsertQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep insertQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep;

	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	RewardsCreateEditListingPage rewardsCreateEditListingPage; // check color rewards
	ResultListingPOT resultListingPOT;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;

	DeleteQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep deleteQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep;

	@Test
	public void stepsForCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep = new InsertQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep();
		insertQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();

		createEditListingPage.clickAllCheckBoxCategories();
		createEditListingPage.clickTickSubcategoryTranslationSecondTestData(); // put tick on the second category
		createEditListingPage.clickSkipToResultButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(2000);
		createEditListingPage.checkAssertionFree();
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		createEditListingPage.checktICkRewardTranslationNameFirst();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();// close
		Thread.sleep(1000);
		createEditListingPage.clickOnCheckBoxOnSecondHeader();// un-tick second header

		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open
		log.info("opened second reward");
		Thread.sleep(1000);
		createEditListingPage.checkTICkRewardTranHeaderSecond();
		Thread.sleep(2000);
		createEditListingPage.checkTICkRewardTranslationNameSecond();

		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // close
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickRewardsButton();

		rewardsCreateEditListingPage = new RewardsCreateEditListingPage(driver);

		rewardsCreateEditListingPage.checkColorForRewardTranslationBlue(); // assert for color blue
		rewardsCreateEditListingPage.checkAssertRewardTranslation();
		rewardsCreateEditListingPage.checkColorForRewardTranslationGraySecond(); // assert for color gray
		rewardsCreateEditListingPage.checkAssertRewardTranslationSecondOne();
		Thread.sleep(2000);
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(2000);
		createEditListingPage.clickOnCheckBoxOnSecondHeader();// select the second header on result
		Thread.sleep(2000);
		createEditListingPage.clickBackToEditCriteriaButton();
		Thread.sleep(2000);

		rewardsCreateEditListingPage.checkColorForRewardTranslationBlue(); // assert for color blue
		rewardsCreateEditListingPage.checkAssertRewardTranslation();
		rewardsCreateEditListingPage.checkColorForSecondRewardTranslationBlue(); // assert for second blue
		rewardsCreateEditListingPage.checkAssertRewardTranslationSecondOne();
		Thread.sleep(2000);
		
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(2000);
		
		createEditListingPage.clickTICkRewardFirstHeader(); // deselect first
		log.info("here 2 ");
		createEditListingPage.clickOnCheckBoxOnSecondHeader();// deselect the second header on result
		Thread.sleep(2000);
		createEditListingPage.clickBackToEditCriteriaButton();
		Thread.sleep(2000);
		rewardsCreateEditListingPage.checkColorForRewardTranslationGrayFirst(); // assert for color gray
		rewardsCreateEditListingPage.checkAssertRewardTranslation();
		rewardsCreateEditListingPage.checkColorForRewardTranslationGraySecond();// assert for color gray
		Thread.sleep(2000);
		rewardsCreateEditListingPage.checkAssertRewardTranslationSecondOne();
		Thread.sleep(2000);

		rewardsCreateEditListingPage.clickRewardTranslationFirst();
		Thread.sleep(2000);
		rewardsCreateEditListingPage.clickRewardTranslationSecondOne();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(2000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open 

		Thread.sleep(2000);
		// createEditListingPage.checkAssertionFree();
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		Thread.sleep(2000);
		createEditListingPage.checktICkRewardTranslationNameFirst();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();// close

		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open second
		log.info("opened second reward");
		Thread.sleep(1000);
		createEditListingPage.checkTICkRewardTranHeaderSecond();
		Thread.sleep(2000);
		createEditListingPage.checkTICkRewardTranslationNameSecond();
		Thread.sleep(2000);
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // close second
		Thread.sleep(2000);
		log.info("closed second reward");
		Thread.sleep(2000);
		
		
		
		
		resultListingPOT = new ResultListingPOT(driver);
		
		resultListingPOT.clickNextButton();

		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		
		automaticUpdateRulesPage.clickSavePOTButton();
		
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open again first 

		Thread.sleep(2000);
		createEditListingPage.checkAssertionFree();
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		createEditListingPage.checktICkRewardTranslationNameFirst();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();// close again first 

		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open again second
		log.info("opened second reward");
		Thread.sleep(1000);
		createEditListingPage.checkTICkRewardTranHeaderSecond();
		Thread.sleep(2000);
		createEditListingPage.checkTICkRewardTranslationNameSecond();

		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // close again second
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickRewardsButton();

		rewardsCreateEditListingPage.checkColorForRewardTranslationBlue(); // assert for color blue
		rewardsCreateEditListingPage.checkAssertRewardTranslation();
		rewardsCreateEditListingPage.checkColorForSecondRewardTranslationBlue(); // assert for second blue
		rewardsCreateEditListingPage.checkAssertRewardTranslationSecondOne();
		
		deleteQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep = new DeleteQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep();
		deleteQueryCheckSelectionOfRewardsFromResultsIsPropagatedToRewardsStep.deleteQuery();

	}

}
