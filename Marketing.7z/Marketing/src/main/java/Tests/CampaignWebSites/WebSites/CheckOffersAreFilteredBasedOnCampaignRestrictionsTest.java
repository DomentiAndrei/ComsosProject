package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersAreFilteredBasedOnCampaignRestrictions.DeleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions;
import DataBase.CheckOffersAreFilteredBasedOnCampaignRestrictions.InsertQueryCheckOffersAreFilteredBasedOnCampaignRestrictions;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.AdditionalPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersAreFilteredBasedOnCampaignRestrictionsTest extends Boss { // TC nr 9655

	InsertQueryCheckOffersAreFilteredBasedOnCampaignRestrictions insertQueryCheckOffersAreFilteredBasedOnCampaignRestrictions;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	AdditionalPage additionalPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;

	DeleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions deleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions;

	@Test(priority = 2)
	public void stepsForCheckOffersAreFilteredBasedOnCampaignRestrictions()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckOffersAreFilteredBasedOnCampaignRestrictions = new InsertQueryCheckOffersAreFilteredBasedOnCampaignRestrictions();
		insertQueryCheckOffersAreFilteredBasedOnCampaignRestrictions.insertQuery();

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());

		
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickAllCheckBoxCategories();
		createEditListingPage.clickTickSubcategoryTranslationSecondTestData();
		createEditListingPage.clickTickSubcategoryTranslationThirdTestData();

		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);

		createEditListingPage.clicNextButtonFromRefineOffers();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();

		additionalPage = new AdditionalPage(driver);
		additionalPage.checkAllCheckBoxes();
		createEditListingPage.clickSkipToResultButton();

		detailsAboutRewardPEN = new DetailsAboutRewardPEN(driver);
		rewarsResultOfLestingPot = new RewarsResultOfLestingPot(driver);
		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkBespoke();

		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		Thread.sleep(1500);
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open second
		rewarsResultOfLestingPot.clickeditButton2ForTCNR9655();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkGeneric();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open second
		Thread.sleep(1500);
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //open third 
		rewarsResultOfLestingPot.clickeditButton3ForTCNR9655();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRFA();
		detailsAboutRewardPEN.clickCloseButton();
		
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //open third 

		resultListingPOT = new ResultListingPOT(driver);
		resultListingPOT.clickNextButton();

		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		automaticUpdateRulesPage.checkAllCompaignRestric();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		
		additionalPage.clickAllCheckBox();
		additionalPage.clickBespokeCheckBox(); // -- Bespoke --
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(2000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkBespoke();

		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		
		
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkBespoke();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		
		additionalPage.clickBespokeCheckBox();
		additionalPage.clickGenericCheckBox(); // -- Generic --
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(2000);
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open second
		rewarsResultOfLestingPot.clickeditButton2ForTCNR9655();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkGeneric();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); // open second
		
		
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkGeneric();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		
		additionalPage.clickGenericCheckBox();
		additionalPage.clickRewardsForAllCheckBox(); // -- RewardsForAll --
		
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(2000);
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //open third 
		rewarsResultOfLestingPot.clickeditButton3ForTCNR9655();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRFA();
		detailsAboutRewardPEN.clickCloseButton();
		
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //open third
		
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkRFA();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();
		createEditListingPage.clickBackToEditCriteriaButton();
		
		

		deleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions = new DeleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions();
		deleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions.deleteQuery();

	}
}
