package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckRewardsThatMatchExperiencesAredisplayedOnResultsPage.DeleteQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage;
import DataBase.CheckRewardsThatMatchExperiencesAredisplayedOnResultsPage.InsertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewardsCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckRewardsThatMatchExperiencesAredisplayedOnResultsPageTest extends Boss { // 9648 third

	InsertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage insertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage;

	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	RewardsCreateEditListingPage rewardsCreateEditListingPage; //check color rewards
	ResultListingPOT resultListingPOT;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	
	
	DeleteQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage deleteQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage;

	@Test
	public void stepsForCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage = new InsertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage();
		insertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickAllCheckBoxCategories();
		createEditListingPage.clickTickSubcategoryTranslationSecondTestData(); // put tick on the second category
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);

		rewardsCreateEditListingPage = new RewardsCreateEditListingPage(driver);

		rewardsCreateEditListingPage.clickRewardTranslationSecondOne();
		
		Thread.sleep(1000);
		createEditListingPage.clickSkipToResultButton();
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // one

		Thread.sleep(1000);
		createEditListingPage.checkAssertionFree();
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		createEditListingPage.checktICkRewardTranslationNameFirst();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();// close
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //open
		log.info("opened second reward");
		Thread.sleep(1000);
		Thread.sleep(1000);
		createEditListingPage.checkTICkRewardTranHeaderSecond();
		Thread.sleep(2000);
		createEditListingPage.checkTICkRewardTranslationNameSecond();
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //close
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickCategoriesButton();
		
		createEditListingPage.clickTickSubcategoryTranslationThirdTestData();
		Thread.sleep(5000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();//after this step need assert 
		rewardsCreateEditListingPage.checkAssertRewardTranslation(); //assert for name
		rewardsCreateEditListingPage.checkAssertRewardTranslationSecondOne();//assert for name
		
		rewardsCreateEditListingPage.checkColorForRewardTranslationBlue(); //assert for color blue
		
		rewardsCreateEditListingPage.checkColorForRewardTranslationGraySecond(); //assert for color gray --
		
		createEditListingPage.clickSkipToResultButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open again 

		Thread.sleep(2000);
		//createEditListingPage.checkAssertionFree();
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		createEditListingPage.checktICkRewardTranslationNameFirst();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();// close
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //open
		log.info("opened second reward");
		Thread.sleep(1000);
		createEditListingPage.checkTICkRewardTranHeaderSecond();
		Thread.sleep(2000);
		createEditListingPage.checkTICkRewardTranslationNameSecond();
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //close
		
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //open third 
		
		createEditListingPage.checkTICkRewardTrHeaderThird();
		createEditListingPage.checktICkRewardTranslationNameThird();
		Thread.sleep(3000);
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //closed third 
		
		resultListingPOT = new ResultListingPOT(driver);
		resultListingPOT.clickNextButton();
		
		
		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		automaticUpdateRulesPage.clickSavePOTButton();
		
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open again 

		Thread.sleep(2000);
		createEditListingPage.checkAssertionFree(); //---
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		createEditListingPage.checktICkRewardTranslationNameFirst();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();// close
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //open
		log.info("opened second reward");
		Thread.sleep(1000);
		createEditListingPage.checkTICkRewardTranHeaderSecond();
		Thread.sleep(2000);
		createEditListingPage.checkTICkRewardTranslationNameSecond();
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //close
		
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //open third 
		
		createEditListingPage.checkTICkRewardTrHeaderThird();
		createEditListingPage.checktICkRewardTranslationNameThird();
		Thread.sleep(3000);
		createEditListingPage.clickThirdListOfResultForNewListingPot(); //closed third 
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickRewardsButton();
		
		rewardsCreateEditListingPage.checkColorForRewardTranslationBlue(); //assert for color blue
		rewardsCreateEditListingPage.checkColorForRewardTranslationGraySecond(); //assert for color gray
		deleteQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage = new DeleteQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage();
		deleteQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage.deleteQuery();
	}

}
