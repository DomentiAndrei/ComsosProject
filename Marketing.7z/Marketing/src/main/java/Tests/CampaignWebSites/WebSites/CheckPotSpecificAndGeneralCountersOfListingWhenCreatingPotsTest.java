package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots.DeleteQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots;
import DataBase.CheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots.InsrtQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.AdditionalPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckPotSpecificAndGeneralCountersOfListingWhenCreatingPotsTest extends Boss { // 10445

	InsrtQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots insrtQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	AdditionalPage additionalPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;

	DeleteQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots deleteQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots;

	@Test(priority = 3)
	public void stepsForCheckOffersAreFilteredBasedOnCampaignRestrictions()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insrtQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots = new InsrtQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots();
		insrtQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");

		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();

		// load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));

		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.checkAmountOfOffers("0");
		detailsOfWebsitePage.checkAmountOfPartners("0");
		detailsOfWebsitePage.checkAmountOfRewards("0");
		detailsOfWebsitePage.checkAmountOfLocations("0");

		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();

		createEditListingPage.clickAllCheckBoxCategories();

		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(1000);

		createEditListingPage.checkAmountOffersOnResultPot();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		resultListingPOT = new ResultListingPOT(driver);
		resultListingPOT.clickNextButton();

		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		automaticUpdateRulesPage.clickSavePOTButton();

		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.checkNumberofOffers("1");
		webSiteListingPot.checknumberofPartners("1");
		webSiteListingPot.checknumberofRewards("1");
		webSiteListingPot.checknumberofLocations("1");

		webSiteListingPot.checkNumberofOffersGeneralCounties("1");
		webSiteListingPot.checknumberofPartnersGeneralCounties("1");
		webSiteListingPot.checknumberofRewardsGeneralCounties("1");
		webSiteListingPot.checknumberofLocationsGeneralCounties("1");

		webSiteListingPot.clickCloseButton();

		detailsOfWebsitePage.checkAmountOfOffers("1");
		detailsOfWebsitePage.checkAmountOfPartners("1");
		detailsOfWebsitePage.checkAmountOfRewards("1");
		detailsOfWebsitePage.checkAmountOfLocations("1");

		detailsOfWebsitePage.clickEditButton();
		webSiteListingPot.clickBinButton();
		
		webSiteListingPot.clickDeletePOTfromPopUp();
		
		webSiteListingPot.clickAddNewPot();
		createYourWebSiteListingPage.ClickUpdateByRewards();
		
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();

		createEditListingPage.clickAllCheckBoxCategories();
		
		createEditListingPage.clickTickSubcategoryTranslationSecondTestData();
		
		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(1000);
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.clickSavePOTButton();
		
		Thread.sleep(2000);
		webSiteListingPot.checkNumberofOffers("2");
		webSiteListingPot.checknumberofPartners("2");
		webSiteListingPot.checknumberofRewards("2");
		webSiteListingPot.checknumberofLocations("2");

		webSiteListingPot.checkNumberofOffersGeneralCounties("2");
		webSiteListingPot.checknumberofPartnersGeneralCounties("2");
		webSiteListingPot.checknumberofRewardsGeneralCounties("2");
		webSiteListingPot.checknumberofLocationsGeneralCounties("2");
		
		webSiteListingPot.clickCloseButton();

		detailsOfWebsitePage.checkAmountOfOffers("2");
		detailsOfWebsitePage.checkAmountOfPartners("2");
		detailsOfWebsitePage.checkAmountOfRewards("2");
		detailsOfWebsitePage.checkAmountOfLocations("2");
		
		

		deleteQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots = new DeleteQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots();
		deleteQueryCheckPotSpecificAndGeneralCountersOfListingWhenCreatingPots.deleteQuery();

	}
}
