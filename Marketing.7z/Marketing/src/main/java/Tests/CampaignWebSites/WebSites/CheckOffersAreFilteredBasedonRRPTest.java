package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersAreFilteredBasedonRRPTest.DeleteQueryCheckOffersAreFilteredBasedonRRP;
import DataBase.CheckOffersAreFilteredBasedonRRPTest.InsertQueryCheckOffersAreFilteredBasedonRRP;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.AdditionalPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersAreFilteredBasedonRRPTest extends Boss { // 9657

	InsertQueryCheckOffersAreFilteredBasedonRRP insertQueryCheckOffersAreFilteredBasedonRRP;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	AdditionalPage additionalPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;

	DeleteQueryCheckOffersAreFilteredBasedonRRP deleteQueryCheckOffersAreFilteredBasedonRRP;

	@Test(priority = 3)
	public void stepsForCheckOffersAreFilteredBasedOnCampaignRestrictions()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckOffersAreFilteredBasedonRRP = new InsertQueryCheckOffersAreFilteredBasedonRRP();
		insertQueryCheckOffersAreFilteredBasedonRRP.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
	
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();

		createEditListingPage.clickAllCheckBoxCategories();

		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);

		createEditListingPage.clicNextButtonFromRefineOffers();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();

		additionalPage = new AdditionalPage(driver);
		additionalPage.checkAllCheckBoxes();

		additionalPage.insertMinRRP("0");
		additionalPage.insertMaxRRP("0");
		createEditListingPage.clickSkipToResultButton();

		detailsAboutRewardPEN = new DetailsAboutRewardPEN(driver);
		rewarsResultOfLestingPot = new RewarsResultOfLestingPot(driver);
		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRRPZero();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		Thread.sleep(3000);

		additionalPage.insertMinRRP("0");
		additionalPage.insertMaxRRP("3000");

		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRRP1500();
		detailsAboutRewardPEN.clickCloseButton();
		
		rewarsResultOfLestingPot.clickEditButton2();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRRPZero();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		Thread.sleep(3000);

		additionalPage.insertMinRRP("5000");
		additionalPage.insertMaxRRP("9999.99");

		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRRP9999();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		Thread.sleep(1000);

		additionalPage.insertMinRRP("5000");
		additionalPage.insertMaxRRP("10000");

		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRRP9999();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		


		
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		
		
		additionalPage.insertMinRRP("5000");
		additionalPage.insertMaxRRP("3000");
		additionalPage.chekcValidationMessageOFRRP();
		
		
		additionalPage.insertMinRRP("5000");
		additionalPage.insertMaxRRP("10000");

		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();

		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkRRP9999();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		


		resultListingPOT =  new ResultListingPOT(driver);
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		Thread.sleep(1000);
		automaticUpdateRulesPage.checkRRPMin();
		Thread.sleep(1000);
		automaticUpdateRulesPage.checkRRPMax();
		
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		

		deleteQueryCheckOffersAreFilteredBasedonRRP = new DeleteQueryCheckOffersAreFilteredBasedonRRP();
		deleteQueryCheckOffersAreFilteredBasedonRRP.deleteQuery();

	}
}
