package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries.DeleteQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries;
import DataBase.CheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries.InsertQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.AdditionalPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries extends Boss { // 9681

	InsertQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries insertQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	AdditionalPage additionalPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;

	DeleteQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries deleteQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries;

	@Test(priority = 4)
	public void stepsForCheckOffersAreFilteredBasedOnCampaignRestrictions()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries = new InsertQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries();
		insertQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");

		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();

		// load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));

		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Website Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsPlusButtonFirst();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();

		createEditListingPage.clickAllCheckBoxCategories();

		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(1000);
		createEditListingPage.checkAmountOffersOnResultPot();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1000);
		createEditListingPage.checklNameofRewords("UK");

		createEditListingPage.clickBackToEditCriteriaButton();

		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage.InsertInSearchField("Website Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();
		detailsOfWebsitePage.clickaddRewardsPlusButtonSecond();

		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();

		createEditListingPage.clickAllCheckBoxCategories();

		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(1000);
		createEditListingPage.checkAmountOffersOnResultPot();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1000);
		createEditListingPage.checklNameofRewords("Ireland");

		deleteQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries = new DeleteQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries();
		deleteQueryCheckOffersAreFilteredBasedOnListingCountryifWebsiteHasMultipleCountries.deleteQuery();
	}
}
