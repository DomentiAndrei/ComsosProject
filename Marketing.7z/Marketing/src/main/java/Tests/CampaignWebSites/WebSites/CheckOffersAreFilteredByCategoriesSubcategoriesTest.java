package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersAreFilteredByCategoriesSubcategories.DeleteQueryCheckOffersAreFilteredByCategoriesSubcategories;
import DataBase.CheckOffersAreFilteredByCategoriesSubcategories.InsertQueryCheckOffersAreFilteredByCategoriesSubcategories;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersAreFilteredByCategoriesSubcategoriesTest extends Boss{ //Test case number #9647 second
	InsertQueryCheckOffersAreFilteredByCategoriesSubcategories insertQueryCheckOffersAreFilteredByCategoriesSubcategories;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	ResultListingPOT resultListingPOT;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	
	DeleteQueryCheckOffersAreFilteredByCategoriesSubcategories deleteQueryCheckOffersAreFilteredByCategoriesSubcategories;
	@Test
	public void stepsForCheckOffersAreFilteredByCategoriesSubcategories() throws InterruptedException, ClassNotFoundException, SQLException {
		insertQueryCheckOffersAreFilteredByCategoriesSubcategories = new InsertQueryCheckOffersAreFilteredByCategoriesSubcategories();
		insertQueryCheckOffersAreFilteredByCategoriesSubcategories.insertQuery();
		
//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//		
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();
		
		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();
	
		websitesPage = new WebsitesPage(driver);
		
		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();
		
		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();
		 
		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();
		
		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.clickNextButton();
		createEditListingPage.clickAllCheckBoxCategories();
		
		createEditListingPage.clickSkipToResultButton();
		createEditListingPage.checkAssertionAll();
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); //check first pot
		Thread.sleep(2000);
		
		createEditListingPage.checkAssertionFree();
		
		resultListingPOT = new ResultListingPOT(driver);
		Thread.sleep(1000);
		resultListingPOT.resultFreeOfferType();
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		Thread.sleep(1500);
	
		createEditListingPage.clickBackToEditCriteriaButton();
		
		createEditListingPage.clickTickSubcategoryTranslationSecondTestData(); //put tick on the second category 
		
		Thread.sleep(5000);
		createEditListingPage.clickSkipToResultButton();
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); //open
		
		Thread.sleep(1000);
		createEditListingPage.checkAssertTransSecond();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();//close
		log.info("closed first reward");
		Thread.sleep(1000);
		createEditListingPage.checkAssertionFree();
		Thread.sleep(1000);
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //open
		log.info("opened second reward");
		Thread.sleep(1000);
		resultListingPOT.resultOfferAutomationTranslationSecondOne();
		createEditListingPage.clickSecondListOfResultsForNewListingPot(); //close
		log.info("closed second reward");
		resultListingPOT.clickNextButton();
		
		
		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		automaticUpdateRulesPage.clickSavePOTButton();
		
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		log.info("opened first reward");
		Thread.sleep(1000);
		createEditListingPage.checkAssertionFree();
		Thread.sleep(1000);
		resultListingPOT.resultFreeOfferType();
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		log.info("closed first reward");
		Thread.sleep(1000);
		createEditListingPage.clickSecondListOfResultsForNewListingPot();
		log.info("opened second reward");
		Thread.sleep(1000);
		
		resultListingPOT.resultOfferAutomationTranslationSecondOne();
		Thread.sleep(1000);
		resultListingPOT.resultOfferAutomationTranslationSecondOne();
		log.info("closed second reward");
		
		createEditListingPage.clickSecondListOfResultsForNewListingPot();
		
		deleteQueryCheckOffersAreFilteredByCategoriesSubcategories = new DeleteQueryCheckOffersAreFilteredByCategoriesSubcategories();
		deleteQueryCheckOffersAreFilteredByCategoriesSubcategories.deleteQuery();
	}
}
