package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersAreFilteredBasedOnLocationType.DeleteQueryCheckOffersAreFilteredBasedOnLocationType;
import DataBase.CheckOffersAreFilteredBasedOnLocationType.InsertQueryCheckOffersAreFilteredBasedOnLocationType;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.LocationPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersAreFilteredBasedOnLocationTypeTest extends Boss { // 9650
	InsertQueryCheckOffersAreFilteredBasedOnLocationType insertQueryCheckOffersAreFilteredBasedOnLocationType;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	LocationPage locationPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;

	DeleteQueryCheckOffersAreFilteredBasedOnLocationType deleteQueryCheckOffersAreFilteredBasedOnLocationType;

	@Test(priority = 1)
	public void stepsForCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckOffersAreFilteredBasedOnLocationType = new InsertQueryCheckOffersAreFilteredBasedOnLocationType();
		insertQueryCheckOffersAreFilteredBasedOnLocationType.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");

//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickAllCheckBoxCategories();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		log.info("here 1");
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		
		createEditListingPage.clicNextButtonFromRefineOffers();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();

		locationPage = new LocationPage(driver);
		locationPage.checkAllCheckBoxes();
		createEditListingPage.clickSkipToResultButton();

		detailsAboutRewardPEN = new DetailsAboutRewardPEN(driver);
		rewarsResultOfLestingPot = new RewarsResultOfLestingPot(driver);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkDelivery();
		detailsAboutRewardPEN.clickCloseButton();
		
		rewarsResultOfLestingPot.clickEditButton2();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkMobile();
		detailsAboutRewardPEN.clickCloseButton();
		
		rewarsResultOfLestingPot.clickEditButton3();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkOnline();
		detailsAboutRewardPEN.clickCloseButton();
		
		rewarsResultOfLestingPot.clickEditButton4();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkVenue();
		detailsAboutRewardPEN.clickCloseButton();
		
		rewarsResultOfLestingPot.clickEditButton5();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkVenueNotListed();
		detailsAboutRewardPEN.clickCloseButton();
		
		
		rewarsResultOfLestingPot.checkAllNameInResultScreen();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first

		resultListingPOT = new ResultListingPOT(driver);

		resultListingPOT.clickNextButton();

		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		automaticUpdateRulesPage.checkAllNameInAutomaticUpdateRulesPage();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first again
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		
		rewarsResultOfLestingPot.checkAllNameInResultScreen();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first again

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickLocationButton();

		locationPage.clickAllCheckBox();
		locationPage.clickMobileCheckBox();
		locationPage.checkTickMobileCheckBox();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(3000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - mobile
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		Thread.sleep(3000);
		rewarsResultOfLestingPot.checkMobile();
		Thread.sleep(3000);
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(3000);
		detailsAboutRewardPEN.checkMobile();
		Thread.sleep(3000);
		detailsAboutRewardPEN.clickCloseButton();
		Thread.sleep(3000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - mobile

		resultListingPOT.clickNextButton();
		log.info("here mob 1");
		Thread.sleep(5000);
		automaticUpdateRulesPage.checkMobile();
		log.info("here mob 2");
		Thread.sleep(3000);
		automaticUpdateRulesPage.clickSavePOTButton();
		log.info("here mob 3");
		Thread.sleep(3000);
		webSiteListingPot.clickEditRewardsButton();
		log.info("here mob 4");
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first second again - mobile
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkMobile();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first second again - mobile

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickLocationButton();
		locationPage.clickMobileCheckBox();
		locationPage.clickVenueCheckBox();
		locationPage.checkTickVenueCheckBx();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(3000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - Venue
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkVenue();
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkVenue();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - Venue

		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkVenue();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - Venue
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkVenue();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - Venue

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickLocationButton();
		locationPage.clickVenueCheckBox();
		locationPage.clickDeliveryCheckBox();
		locationPage.checkTickDeliVeryCheckBox();
		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(3000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - Delivery
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkDelivery();
		
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkDelivery();
		detailsAboutRewardPEN.clickCloseButton();
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - Delivery

		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkDelivery();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - Delivery
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkDelivery();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - Delivery

		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickLocationButton();
		locationPage.clickDeliveryCheckBox();
		locationPage.clickOnlineCheckBox();
		locationPage.checkTickOnlineCheckBox();
		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(3000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - Online
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkOnline();
		
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkOnline();
		detailsAboutRewardPEN.clickCloseButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - Online

		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkOnline();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();
		
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - Online
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkOnline();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - Online
		
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickLocationButton();
		locationPage.clickOnlineCheckBox();
		locationPage.clickVenueNotListedCheckBox();
		locationPage.checkVenueNotListedCheckBox();
		createEditListingPage.clickSkipToResultButton();



		Thread.sleep(3000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - VenueNotListed
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkVenueNotListed();
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkVenueNotListed();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - VenueNotListed
		
		
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage.checkVenueNotListed();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();
		
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first - VenueNotListed
		Thread.sleep(3000);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.checkVenueNotListed();
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first - VenueNotListed
		
		

		deleteQueryCheckOffersAreFilteredBasedOnLocationType = new DeleteQueryCheckOffersAreFilteredBasedOnLocationType();
		deleteQueryCheckOffersAreFilteredBasedOnLocationType.deleteQuery();
	}
}
