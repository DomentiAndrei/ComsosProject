package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersAreFilteredBasedonMaximumBECost.DeleteQueryCheckOffersAreFilteredBasedonMaximumBECost;
import DataBase.CheckOffersAreFilteredBasedonMaximumBECost.InsertQueryCheckOffersAreFilteredBasedonMaximumBECost;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.AdditionalPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersAreFilteredBasedonMaximumBECostTest extends Boss{

	
	InsertQueryCheckOffersAreFilteredBasedonMaximumBECost insertQueryCheckOffersAreFilteredBasedonMaximumBECost;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	AdditionalPage additionalPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;

	DeleteQueryCheckOffersAreFilteredBasedonMaximumBECost deleteQueryCheckOffersAreFilteredBasedonMaximumBECost;

	@Test(priority = 2)
	public void stepsForCheckOffersAreFilteredBasedOnCampaignRestrictions()
			throws ClassNotFoundException, SQLException, InterruptedException {

		insertQueryCheckOffersAreFilteredBasedonMaximumBECost = new InsertQueryCheckOffersAreFilteredBasedonMaximumBECost();
		insertQueryCheckOffersAreFilteredBasedonMaximumBECost.insertQuery();

//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.clickNextButton();
		
		createEditListingPage.clickAllCheckBoxCategories();
		
		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);

		createEditListingPage.clicNextButtonFromRefineOffers();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();

		additionalPage = new AdditionalPage(driver);
		additionalPage.checkAllCheckBoxes();
		createEditListingPage.clickSkipToResultButton();
		
		Thread.sleep(1000);
//		additionalPage.checkAdditionalNumber();
//		additionalPage.checkZeroOnSlaider();
		
		
		
		detailsAboutRewardPEN = new DetailsAboutRewardPEN(driver);
		rewarsResultOfLestingPot = new RewarsResultOfLestingPot(driver);
		Thread.sleep(1500);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		
		
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkBackEndCostZero();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		resultListingPOT =  new ResultListingPOT(driver);
		resultListingPOT.clickNextButton();
		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		automaticUpdateRulesPage.checkBackEndCostZero();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.clickEditRewardsButton();
	
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		Thread.sleep(3000);
		additionalPage.insertAdditionalNumber("1");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("5");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("0");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("0");
		Thread.sleep(3000);
		createEditListingPage.clickSkipToResultButton();

		Thread.sleep(2000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		log.info("here 2");
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.clickEditButton1();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkBackEndCost1500();
		detailsAboutRewardPEN.clickCloseButton();
		
		rewarsResultOfLestingPot.clickEditButton2();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkBackEndCostZero();
		detailsAboutRewardPEN.clickCloseButton();

		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		
		
		resultListingPOT.clickNextButton();
		log.info("here 32");
		Thread.sleep(2000);
		automaticUpdateRulesPage.checkBackEndCost1500();
		automaticUpdateRulesPage.clickSavePOTButton();
		webSiteListingPot.clickEditRewardsButton();
	
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickAdditionalButton();
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("9");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("9");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("9");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("9");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("9");
		Thread.sleep(1000);
		additionalPage.insertAdditionalNumber("9");
		
		createEditListingPage.clickSkipToResultButton();
		
		Thread.sleep(3000);
		
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // open first
		Thread.sleep(1500);
		
		createEditListingPage.checkTICkRewardTrHeaderFirst();
		rewarsResultOfLestingPot.clickEditButton2();
		Thread.sleep(1000);
		detailsAboutRewardPEN.checkBackEndCost9999();
		detailsAboutRewardPEN.clickCloseButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot(); // close first
		
		
		deleteQueryCheckOffersAreFilteredBasedonMaximumBECost =  new DeleteQueryCheckOffersAreFilteredBasedonMaximumBECost();
		deleteQueryCheckOffersAreFilteredBasedonMaximumBECost.deleteQuery();
		
		
		
	}
	
}
