package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckDisplayedRulesAreConsistentWithAppliedFilters.DeleteQueryCheckDisplayedRulesAreConsistentWithAppliedFilters;
import DataBase.CheckDisplayedRulesAreConsistentWithAppliedFilters.InsertQueryCheckDisplayedRulesAreConsistentWithAppliedFilters;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.AutomaticUpdateRulesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebSiteListingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.AdditionalPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards.LocationPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.DetailsAboutRewardPEN;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.RewarsResultOfLestingPot;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckDisplayedRulesAreConsistentWithAppliedFiltersTest extends Boss { // 9669

	InsertQueryCheckDisplayedRulesAreConsistentWithAppliedFilters insertQueryCheckDisplayedRulesAreConsistentWithAppliedFilters;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	AdditionalPage additionalPage;
	RewarsResultOfLestingPot rewarsResultOfLestingPot;
	AutomaticUpdateRulesPage automaticUpdateRulesPage;
	WebSiteListingPot webSiteListingPot;
	ResultListingPOT resultListingPOT;
	DetailsAboutRewardPEN detailsAboutRewardPEN;
	LocationPage locationPage;

	DeleteQueryCheckDisplayedRulesAreConsistentWithAppliedFilters deleteQueryCheckDisplayedRulesAreConsistentWithAppliedFilters;

	@Test(priority = 3)
	public void stepsForCheckOffersAreFilteredBasedOnCampaignRestrictions()
			throws ClassNotFoundException, SQLException, InterruptedException, IOException {

		insertQueryCheckDisplayedRulesAreConsistentWithAppliedFilters = new InsertQueryCheckDisplayedRulesAreConsistentWithAppliedFilters();
		insertQueryCheckDisplayedRulesAreConsistentWithAppliedFilters.insertQuery();
//		File file = new File("..\\Marketing\\config.properties");
//		  
//		FileInputStream fileInput = null;
//		try {
//			fileInput = new FileInputStream(file);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		Properties prop = new Properties();
//		
//		//load properties file
//	
//			prop.load(fileInput);
		
		LogInElements logInElements = new LogInElements(driver);
		//logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		logInElements.logInAutoTest(System.getenv("usernameCosmos"), System.getenv("passwordCosmos"));
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());

		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();

		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();

		websitesPage = new WebsitesPage(driver);

		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();

		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();

		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();

		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
		createEditListingPage.ClickAllCheckBox();
		createEditListingPage.clickDiscountCheckBox();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickAllCheckBoxCategories();

		createEditListingPage.clickNextButton();
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);
		createEditListingPage.clickNextButton();
		Thread.sleep(1000);

		createEditListingPage.clicNextButtonFromRefineOffers();
		Thread.sleep(1000);

		createEditListingPage.clickNextButton();
		locationPage = new LocationPage(driver);
		locationPage.clickAllCheckBox();
		locationPage.clickVenueCheckBox();
		createEditListingPage.clickNextButton();

		additionalPage = new AdditionalPage(driver);
		additionalPage.checkAllCheckBoxes();
		additionalPage.clickAllCheckBox();
		additionalPage.clickGenericCheckBox();
		additionalPage.insertAdditionalNumber("1");
		additionalPage.insertAdditionalNumber("5");
		additionalPage.insertAdditionalNumber("0");
		additionalPage.insertAdditionalNumber("0");

		additionalPage.insertMinRRP("0");
		additionalPage.insertMaxRRP("9999.99");

		createEditListingPage.clickSkipToResultButton();

		resultListingPOT = new ResultListingPOT(driver);
		Thread.sleep(3000);
		resultListingPOT.clickNextButton();

		automaticUpdateRulesPage = new AutomaticUpdateRulesPage(driver);
		Thread.sleep(3000);

		automaticUpdateRulesPage.checkColorOfSwitcher();

		automaticUpdateRulesPage.checkNumberOfOffersOnPage();
		automaticUpdateRulesPage.checkDiscount();
		automaticUpdateRulesPage.checkRewardTranslation();
		automaticUpdateRulesPage.checkVenue();
		automaticUpdateRulesPage.checkGeneric();
		automaticUpdateRulesPage.checkBackEndCost1500();
		automaticUpdateRulesPage.checkRRPZero();
		automaticUpdateRulesPage.checkRRPMax();

		automaticUpdateRulesPage.clickSavePOTButton();

		webSiteListingPot = new WebSiteListingPot(driver);
		webSiteListingPot.checkNameOfReward();
		webSiteListingPot.checkLastUpdated();
		webSiteListingPot.checkNumberofOffers("1");
		webSiteListingPot.checknumberofPartners("1");
		webSiteListingPot.checknumberofRewards("1");
		webSiteListingPot.checknumberofLocations("1");

		deleteQueryCheckDisplayedRulesAreConsistentWithAppliedFilters = new DeleteQueryCheckDisplayedRulesAreConsistentWithAppliedFilters();
		deleteQueryCheckDisplayedRulesAreConsistentWithAppliedFilters.deleteQuery();

	}

}
