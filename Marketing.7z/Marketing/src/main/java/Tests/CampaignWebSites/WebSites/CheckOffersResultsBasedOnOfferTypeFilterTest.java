package Tests.CampaignWebSites.WebSites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.Test;

import DataBase.CheckOffersResultsBasedOnOfferTypeFilter.DeleteQueryCheckOffersResultsBasedOnOfferTypeFilter;
import DataBase.CheckOffersResultsBasedOnOfferTypeFilter.InsertQueryCheckOffersResultsBasedOnOfferTypeFilter;
import LeftBarMenu.CampaignWebSites.PathsClientsCampaignsWebsites;
import TCL.Marketing.Boss;
import TCL.Marketing.UpBarSide;
import TCL.Marketing.Elements.LogInElements;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CreateYourWebSiteListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.WebsitesPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.DetailsOfWebsitePage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage.OfferTypeCreateEditListingPage;
import TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements.ResultListingPOT;

public class CheckOffersResultsBasedOnOfferTypeFilterTest extends Boss{ //Test case ID: 9646 first
	InsertQueryCheckOffersResultsBasedOnOfferTypeFilter queryCheckOffersResultsBasedOnOfferTypeFilter;
	UpBarSide upBarSide;
	PathsClientsCampaignsWebsites pathsClientsCampaignsWebsites;
	WebsitesPage websitesPage;
	DetailsOfWebsitePage detailsOfWebsitePage;
	CreateYourWebSiteListingPage createYourWebSiteListingPage;
	OfferTypeCreateEditListingPage createEditListingPage;
	ResultListingPOT resultListingPOT;
	
	DeleteQueryCheckOffersResultsBasedOnOfferTypeFilter deleteQueryCheckOffersResultsBasedOnOfferTypeFilter;
	@Test
	public void stepsForCheckOffersResultsBasedOnOfferTypeFilter() throws InterruptedException, ClassNotFoundException, SQLException {
		queryCheckOffersResultsBasedOnOfferTypeFilter = new InsertQueryCheckOffersResultsBasedOnOfferTypeFilter();
		queryCheckOffersResultsBasedOnOfferTypeFilter.insertQuery();
		
//		LogInElements logInElements = new LogInElements(driver);
//		logInElements.logInAutoTest("Dev-Cosmos-GlobalAdmin@tlcmarketing.com", "Wucu5990!!");
//		
//		String CheckWelcome = "Welcome back, !";
//		Thread.sleep(1000);
//		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogInElements logInElements = new LogInElements(driver);
		logInElements.logInAutoTest(prop.getProperty("username"), prop.getProperty("password"));
		
		
		
		String CheckWelcome = "Welcome back, !";
		Thread.sleep(1000);
		Assert.assertEquals(CheckWelcome, logInElements.checkMessage());
		upBarSide = new UpBarSide(driver);
		upBarSide.clickDropDownCountru();
		upBarSide.clickAutomation();
		
		pathsClientsCampaignsWebsites = new PathsClientsCampaignsWebsites(driver);
		pathsClientsCampaignsWebsites.clickCampaignsWebsites();
		pathsClientsCampaignsWebsites.clickWebsites();
	
		websitesPage = new WebsitesPage(driver);
		
		Thread.sleep(1000);
		websitesPage.InsertInSearchField("Automation");
		Thread.sleep(1000);
		websitesPage.clickSearchButton();
		Thread.sleep(1000);
		websitesPage.clickViewButton();
		
		detailsOfWebsitePage = new DetailsOfWebsitePage(driver);
		detailsOfWebsitePage.clickAddRewardsbutton();
		 
		createYourWebSiteListingPage = new CreateYourWebSiteListingPage(driver);
		createYourWebSiteListingPage.ClickUpdateByRewards();
		
		
		createEditListingPage = new OfferTypeCreateEditListingPage(driver);
		createEditListingPage.checkAssertionAll();
	
		createEditListingPage.clickNextButton();
		
		Thread.sleep(1000);
		createEditListingPage.clickAllCheckBoxCategories();
		
		Thread.sleep(1000);
		createEditListingPage.clickSkipToResultButton();
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		
		resultListingPOT = new ResultListingPOT(driver);
		
		Thread.sleep(500); 
		resultListingPOT.CheckAllAsserts();
		
		Thread.sleep(500); 
		
		createEditListingPage.clickBackToEditCriteriaButton();
		
		createEditListingPage.clickOfferTypeButton();
		

		createEditListingPage.ClickAllCheckBox();//deselect all
		createEditListingPage.clickFreeCheckBox();
		Thread.sleep(1000);
		createEditListingPage.checkAssertionFree();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(500); 
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		Thread.sleep(500); 
		resultListingPOT.resultFreeOfferType();
		Thread.sleep(500); 
		/// add assert that just one in the list 
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickOfferTypeButton();
		createEditListingPage.clickFreeCheckBox();
		createEditListingPage.clickTwoToOneBox();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		Thread.sleep(1000);
		resultListingPOT.resultOfferTwoForOneAutomationTranslation();
		Thread.sleep(1000);
//		/// add assert that just one in the list 
		
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickOfferTypeButton();
		createEditListingPage.clickTwoToOneBox();
		createEditListingPage.clickThreeForTwoCheckBox();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		Thread.sleep(1000);
		resultListingPOT.resultOfferThreeForTwoAutomationTranslation();
		
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickOfferTypeButton();
		createEditListingPage.clickThreeForTwoCheckBox();
		createEditListingPage.clickDiscountCheckBox();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(1000);
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		Thread.sleep(1000);
		resultListingPOT.resultDiscauntOfferType();
//		/// add assert that just one in the list 
		
		
		createEditListingPage.clickBackToEditCriteriaButton();
		createEditListingPage.clickOfferTypeButton();
		createEditListingPage.clickDiscountCheckBox();
		createEditListingPage.clickXforYCheckBox();
		createEditListingPage.clickNextButton();
		createEditListingPage.clickSkipToResultButton();
		Thread.sleep(500); 
		createEditListingPage.clickFirstListOfResultsForNewListingPot();
		Thread.sleep(500); 
		resultListingPOT.checkForXToY();
		/// add assert that just one in the list 
		
		
		deleteQueryCheckOffersResultsBasedOnOfferTypeFilter =  new DeleteQueryCheckOffersResultsBasedOnOfferTypeFilter();
		deleteQueryCheckOffersResultsBasedOnOfferTypeFilter.deleteQuery();
		
		
	}
}
