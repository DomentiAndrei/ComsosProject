package DataBase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class AccessToFile {

	public void connectionToDB() throws ClassNotFoundException, SQLException {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		File file = new File("..\\Marketing\\config.properties");

		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();

		// load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}

		Connection conn = DriverManager.getConnection(prop.getProperty("serverDatabase"), prop.getProperty("UserId"),
				prop.getProperty("passwordd"));
		conn.nativeSQL("Clients");

		System.out.println("Connected successfully");
		Statement st = conn.createStatement();

		
		
		
	}
}
