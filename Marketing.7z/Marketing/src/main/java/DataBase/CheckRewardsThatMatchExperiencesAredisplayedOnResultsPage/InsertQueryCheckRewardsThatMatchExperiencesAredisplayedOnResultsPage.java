package DataBase.CheckRewardsThatMatchExperiencesAredisplayedOnResultsPage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.Test;

public class InsertQueryCheckRewardsThatMatchExperiencesAredisplayedOnResultsPage {

	@Test
	public void insertQuery() throws ClassNotFoundException, SQLException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Connection conn = DriverManager.getConnection(
				prop.getProperty("serverDatabase"),
				prop.getProperty("UserId"),
				prop.getProperty("passwordd"));
		conn.nativeSQL("Clients");
		
		System.out.println("Connected successfully");

		Statement st = conn.createStatement();

		String Languages = "SET IDENTITY_INSERT [Languages] ON\r\n"
				+ "  INSERT INTO [Languages] ( [Id],[Name],[ShortName],[Enabled],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion])\r\n"
				+ "  VALUES (1000, 'Automation', 'ah-TO', 1, GETDATE(), null, null, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [Languages] OFF";
		String Countries = "SET IDENTITY_INSERT [Countries] ON\r\n"
				+ "  INSERT INTO [Countries] ([Id],[Name],[Code],[DefaultLanguageId],[Currency],[DistanceUnit],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[IsEnabled],[RowVersion],[WebsiteClusterId])\r\n"
				+ "  VALUES (1000, 'Automation', 'AH', 1000, 'EUR', 'KM', GETDATE(), null, null, null, 1, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [Countries] OFF";
		String CountryLanguages = "INSERT INTO [CountryLanguages] ([CountryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion])\r\n"
				+ "  VALUES (1000, 1000, GETDATE(), null, null, null, null)";
		String Clients = "SET IDENTITY_INSERT [Clients] ON\r\n"
				+ "  INSERT INTO [Clients] ([Id],[Number],[Name],[CountryId],[IsEnabled],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Address],[Address2],[Address3],[City],[ExternalId],[ExternalRowVersion],[Postcode],[State],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 'Client-01', 'Client Automation' , 1000 , 1, GETDATE(), null, null, null, null, null, null, null, null, null, 0, null, null, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [Clients] OFF";
		String Campaigns = "SET IDENTITY_INSERT [Campaigns] ON\r\n"
				+ "  INSERT INTO [Campaigns] ([Id],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Name],[CampaignNumber],[CountryId],[EndDate],[IsEnabled],[StartDate],[IsCrossBorder],[Description],[ClientId],[CampaignReference],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, GETDATE(), null, null, null, null, 'Campaign Automation', 'CMP-Auto', 1000, GETDATE(), 1, GETDATE(), 1, null, 100, null, null, 0 , null, null)\r\n"
				+ "  SET IDENTITY_INSERT [Campaigns] OFF";
		String Websites = "SET IDENTITY_INSERT [Websites] ON\r\n"
				+ "  INSERT INTO [Websites] ([Id],[Number],[Name],[Status],[CampaignId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[EndDate],[StartDate],[Url],[AgencyId],[Description],[NumberCounter],[CountryId],[WebsiteKey],[WebsiteClusterId])\r\n"
				+ "  VALUES (1000, 'WEB-AUTO', 'Website Automation', 'Live' , 100 , GETDATE(), null, null, null, null, GETDATE(), GETDATE(), 'https://google.com/' , null, null, 1,1000 , null, null  )\r\n"
				+ "SET IDENTITY_INSERT [Websites] OFF";
		String Listings = "SET IDENTITY_INSERT [Listings] ON\r\n"
				+ "  INSERT INTO [Listings] ([Id],[WebsiteId],[CountryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[IsDefault])\r\n"
				+ "  Values (1000, 1000, 1000, GETDATE(), null, null, null, null, 1)\r\n"
				+ "  SET IDENTITY_INSERT [Listings] OFF";

		st.addBatch(Languages);
		st.addBatch(Countries);
		st.addBatch(CountryLanguages);
		st.addBatch(Clients);
		st.addBatch(Campaigns);
		st.addBatch(Websites);
		st.addBatch(Listings);

		st.executeBatch();

		/// ch
		String Categories = "SET IDENTITY_INSERT Categories ON\r\n"
				+ "  INSERT INTO Categories ([Id],[Enabled],[ImageUrl],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Description],[LogoUrl],[Name],[ExternalId],[ExternalRowVersion],[BannerUrl],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 1, null, GETDATE(), null, null, null, null, 'description' , null, 'Category Automation', null, 0, null, null, null);\r\n"
				+ "  SET IDENTITY_INSERT Categories OFF";
		String LocalizedCategories = "SET IDENTITY_INSERT [LocalizedCategories] ON\r\n"
				+ "  INSERT INTO LocalizedCategories ([Id],[Name],[Description],[LogoUrl],[CategoryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[BannerUrl],[ImageUrl],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (30, 'Category Translation', 'description' , null, 100 , 1000, GETDATE(), null, null ,null, null, null, 0, null, null, null, null)\r\n"
				+ "   SET IDENTITY_INSERT [LocalizedCategories] OFF";
		String Subcategories = "SET IDENTITY_INSERT Subcategories ON\r\n"
				+ "   INSERT INTO Subcategories([Id],[Enabled],[ParentCategoryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[BannerUrl],[Description],[LogoUrl],[MainImageUrl],[Name],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "   VALUES (100, 1 , 100, GETDATE(), null, null, null, null, null, 'description', null, null, 'Subcategory Automation', null, 0, null, null)\r\n"
				+ "   SET IDENTITY_INSERT Subcategories OFF";
		String LocalizedSubcategories = "SET IDENTITY_INSERT [LocalizedSubcategories] ON\r\n"
				+ "  INSERT INTO [LocalizedSubcategories] ([Id],[Name],[Description],[LogoUrl],[MainImageUrl],[BannerUrl],[SubcategoryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (50, 'Subcategory Translation', 'description', null, null, null, 100, 1000, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedSubcategories] OFF";
		String Experiences = "SET IDENTITY_INSERT Experiences ON\r\n"
				+ "  INSERT INTO Experiences([Id],[SubcategoryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[IsEnabled],[BannerUrl],[LogoUrl],[MainImageUrl],[Title],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 100, GETDATE(), null, null, null, null, 1, null, null, null, 'Experience-Automation', null, 0 , null, null )\r\n"
				+ "  SET IDENTITY_INSERT Experiences OFF";
		String LocalizedExperience = "SET IDENTITY_INSERT LocalizedExperience ON\r\n"
				+ "  INSERT INTO LocalizedExperience ([Id],[Title],[LanguageId],[LogoUrl],[MainImageUrl],[BannerUrl],[ExperienceId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 'Experience Translation', 1000, null , null, null, 100, GETDATE(), null , null, null, null, null, 0, null, null )\r\n"
				+ "  SET IDENTITY_INSERT LocalizedExperience OFF";
		String Rewards = "SET IDENTITY_INSERT [Rewards] ON\r\n"
				+ "  INSERT INTO [Rewards] ([Id],[ExperienceId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Credits],[IsEnabled],[Title],[ExternalId],[ExternalRowVersion],[RewardReference],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 100, GETDATE(), null, null, null, null, 20, 1, 'Reward Automation', null, 0, null, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [Rewards] OFF";
		String LocalizedRewards = "SET IDENTITY_INSERT [LocalizedRewards] ON\r\n"
				+ "  INSERT INTO [LocalizedRewards] ([Id],[Name],[TermsOfOffer],[LanguageId],[RewardId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 'Reward Translation', 'terms of offer', 1000, 100, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedRewards] OFF";
		String Partners = "SET IDENTITY_INSERT [Partners] ON\r\n"
				+ "  INSERT INTO [Partners] ([Id],[Name],[Address],[City],[State],[Postcode],[Phone],[Email],[VatNo],[CompanyNo],[PartnerType],[IsCrossBorder],[LogoUrl],[MainImageUrl],[Notes],[IsEnabled],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[CountryId],[ExternalId],[ExternalRowVersion],[Address2],[Address3],[PartnerReference],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES(20, 'Automation Partner', 'address', 'city', 'state', '3333333333333' ,'MD-123', 'nokla@gmail.com' , '22222222', '22222222' , 'Independent', 1, null, null, null, 1, GETDATE(), null, null, null, null, 1000, null, 0, null, null, null, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [Partners] OFF";
		String PartnerLocations = "  SET IDENTITY_INSERT [PartnerLocations] ON\r\n"
				+ "  INSERT INTO [PartnerLocations] ([Id],[Name],[Address],[City],[County],[CountryId],[Region],[Postcode],[Phone],[Email],[Website],[OpeningHours],[LocationType],[DisabledAccess],[IsEnabled],[Radius],[PartnerId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Address2],[Address3],[LogoUrl],[MainImageUrl],[Geolocation],[ExternalId],[ExternalRowVersion],[LocationReference],[AdministrativeUnit1Id],[AdministrativeUnit2Id],[AdministrativeUnit3Id],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 'Automation Location', 'address', 'city', 'county', 1000, 'state', 'postcode' , '12345678978' , 'email@mail.com', 'website.com', '14-18', 'Venue' , 'Unknown' , 1, 15, 20, GETDATE(), null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [PartnerLocations] OFF";
		String LocalizedPartnerLocations = "SET IDENTITY_INSERT [LocalizedPartnerLocations] ON\r\n"
				+ "  INSERT INTO [LocalizedPartnerLocations] ([Id],[Name],[Address],[Address2],[Address3],[City],[County],[Country],[Region],[Postcode],[Phone],[Email],[Website],[OpeningHours],[LanguageId],[PartnerLocationId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (10, 'Automation Translation', 'Address 1 localization', 'Address 2 localization', 'Address 3 localization', 'city localization', 'county localization', 'country localization', 'state localization', 'MD-1234', '2134234213421', 'dfsdfsadf@test.com', 'website.com', '14-18', 1000, 100, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "    SET IDENTITY_INSERT [LocalizedPartnerLocations] OFF";

		String OffersFree = "SET IDENTITY_INSERT [Offers] ON --- de 5 ori cu offers differit\r\n"
				+ "  INSERT INTO [Offers] ([Id],[Name],[Type],[IsEnabled],[PartnerLocationId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[AgeFrom],[AgeTo],[AvailableFrom],[AvailableTo],[Cost],[RedemptionLimit],[RewardId],[Rrp],[CampaignRestriction],[RedemptionCodeType],[ExternalId],[ExternalRowVersion],[Discount],[FreeItemsCount],[Get],[MoneyOff],[MoneyOffSpent],[PayFor],[OfferReference],[SubscriptionPeriod],[DeletedAt],[IsDeleted]) \r\n"
				+ "  VALUES (100, 'Offer Automation', 'Free', 1, 100, GETDATE(), null, null, null, null, 10, 50, GETDATE(), GETDATE(), 0.00, 'Unlimited', 100, 0.00, 'Generic', 'TLCRedemptionCode', null, 0 , null, null, null, null, null, null, null, null, null, null )\r\n"
				+ "  SET IDENTITY_INSERT [Offers] OFF";

		String LocalizedOffersFree = "SET IDENTITY_INSERT [LocalizedOffers] ON ---- 5 translations \r\n"
				+ "  INSERT INTO [LocalizedOffers] ([Id],[Name],[TermsOfOffer],[LanguageId],[OfferId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (100, 'Offer Automation Translation', 'terms of offer', 1000, 100, GETDATE(), null, null, null, null, null, 0, null, null )\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedOffers] OFF";

		Statement stAddition = conn.createStatement();

		stAddition.addBatch(Categories);
		stAddition.addBatch(LocalizedCategories);
		stAddition.addBatch(Subcategories);
		stAddition.addBatch(LocalizedSubcategories);
		stAddition.addBatch(Experiences);
		stAddition.addBatch(LocalizedExperience);
		stAddition.addBatch(Rewards);
		stAddition.addBatch(LocalizedRewards);
		stAddition.addBatch(Partners);
		stAddition.addBatch(PartnerLocations);
		stAddition.addBatch(LocalizedPartnerLocations);

		stAddition.addBatch(OffersFree);
		stAddition.addBatch(LocalizedOffersFree);

		stAddition.executeBatch();

		/// Second ch

		String CategoriesSecond = "SET IDENTITY_INSERT Categories ON\r\n"
				+ "  INSERT INTO Categories ([Id],[Enabled],[ImageUrl],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Description],[LogoUrl],[Name],[ExternalId],[ExternalRowVersion],[BannerUrl],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 1, null, GETDATE(), null, null, null, null, 'description' , null, 'Category Automation', null, 0, null, null, null);\r\n"
				+ "  SET IDENTITY_INSERT Categories OFF" + "";
		String LocalizedCategoriesSecond = "SET IDENTITY_INSERT [LocalizedCategories] ON\r\n"
				+ "  INSERT INTO LocalizedCategories ([Id],[Name],[Description],[LogoUrl],[CategoryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[BannerUrl],[ImageUrl],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (31, 'Category Translation SecondOne', 'description' , null, 101 , 1000, GETDATE(), null, null ,null, null, null, 0, null, null, null, null)\r\n"
				+ "   SET IDENTITY_INSERT [LocalizedCategories] OFF";
		String SubcategoriesSecond = "SET IDENTITY_INSERT Subcategories ON\r\n"
				+ "   INSERT INTO Subcategories([Id],[Enabled],[ParentCategoryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[BannerUrl],[Description],[LogoUrl],[MainImageUrl],[Name],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "   VALUES (101, 1 , 101, GETDATE(), null, null, null, null, null, 'description', null, null, 'Subcategory Automation', null, 0, null, null)\r\n"
				+ "   SET IDENTITY_INSERT Subcategories OFF";
		String LocalizedSubcategoriesSecond = "SET IDENTITY_INSERT [LocalizedSubcategories] ON\r\n"
				+ "  INSERT INTO [LocalizedSubcategories] ([Id],[Name],[Description],[LogoUrl],[MainImageUrl],[BannerUrl],[SubcategoryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (51, 'Subcategory Translation Second Test data ', 'description', null, null, null, 101, 1000, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedSubcategories] OFF";
		String ExperiencesSecond = "SET IDENTITY_INSERT Experiences ON\r\n"
				+ "  INSERT INTO Experiences([Id],[SubcategoryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[IsEnabled],[BannerUrl],[LogoUrl],[MainImageUrl],[Title],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 101, GETDATE(), null, null, null, null, 1, null, null, null, 'Experience-Automation', null, 0 , null, null )\r\n"
				+ "  SET IDENTITY_INSERT Experiences OFF";
		String LocalizedExperienceSecond = "SET IDENTITY_INSERT LocalizedExperience ON\r\n"
				+ "  INSERT INTO LocalizedExperience ([Id],[Title],[LanguageId],[LogoUrl],[MainImageUrl],[BannerUrl],[ExperienceId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 'Experience Translation SecondOne', 1000, null , null, null, 101, GETDATE(), null , null, null, null, null, 0, null, null )\r\n"
				+ "  SET IDENTITY_INSERT LocalizedExperience OFF";
		String RewardsSecond = "SET IDENTITY_INSERT [Rewards] ON\r\n"
				+ "  INSERT INTO [Rewards] ([Id],[ExperienceId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Credits],[IsEnabled],[Title],[ExternalId],[ExternalRowVersion],[RewardReference],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 101, GETDATE(), null, null, null, null, 20, 1, 'Reward Automation', null, 0, null, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [Rewards] OFF";
		String LocalizedRewardsSecond = "SET IDENTITY_INSERT [LocalizedRewards] ON\r\n"
				+ "  INSERT INTO [LocalizedRewards] ([Id],[Name],[TermsOfOffer],[LanguageId],[RewardId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 'Reward Translation SecondOne', 'terms of offer', 1000, 101, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedRewards] OFF";
		String PartnersSecond = "SET IDENTITY_INSERT [Partners] ON\r\n"
				+ "  INSERT INTO [Partners] ([Id],[Name],[Address],[City],[State],[Postcode],[Phone],[Email],[VatNo],[CompanyNo],[PartnerType],[IsCrossBorder],[LogoUrl],[MainImageUrl],[Notes],[IsEnabled],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[CountryId],[ExternalId],[ExternalRowVersion],[Address2],[Address3],[PartnerReference],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES(21, 'Automation Partner', 'address', 'city', 'state', '3333333333333' ,'MD-123', 'nokla@gmail.com' , '22222222', '22222222' , 'Independent', 1, null, null, null, 1, GETDATE(), null, null, null, null, 1000, null, 0, null, null, null, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [Partners] OFF";
		String PartnerLocationsSecond = "SET IDENTITY_INSERT [PartnerLocations] ON\r\n"
				+ "  INSERT INTO [PartnerLocations] ([Id],[Name],[Address],[City],[County],[CountryId],[Region],[Postcode],[Phone],[Email],[Website],[OpeningHours],[LocationType],[DisabledAccess],[IsEnabled],[Radius],[PartnerId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Address2],[Address3],[LogoUrl],[MainImageUrl],[Geolocation],[ExternalId],[ExternalRowVersion],[LocationReference],[AdministrativeUnit1Id],[AdministrativeUnit2Id],[AdministrativeUnit3Id],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 'Automation Location', 'address', 'city', 'county', 1000, 'state', 'postcode' , '12345678978' , 'email@mail.com', 'website.com', '14-18', 'Venue' , 'Unknown' , 1, 15, 21, GETDATE(), null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [PartnerLocations] OFF";
		String LocalizedPartnerLocationsSecond = "SET IDENTITY_INSERT [LocalizedPartnerLocations] ON\r\n"
				+ "  INSERT INTO [LocalizedPartnerLocations] ([Id],[Name],[Address],[Address2],[Address3],[City],[County],[Country],[Region],[Postcode],[Phone],[Email],[Website],[OpeningHours],[LanguageId],[PartnerLocationId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (11, 'Automation Translation SecondOne', 'Address 1 localization', 'Address 2 localization', 'Address 3 localization', 'city localization', 'county localization', 'country localization', 'state localization', 'MD-1234', '2134234213421', 'dfsdfsadf@test.com', 'website.com', '14-18', 1000, 101, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "    SET IDENTITY_INSERT [LocalizedPartnerLocations] OFF";
		String OffersFreeSecond = "SET IDENTITY_INSERT [Offers] ON --- de 5 ori cu offers differit\r\n"
				+ "  INSERT INTO [Offers] ([Id],[Name],[Type],[IsEnabled],[PartnerLocationId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[AgeFrom],[AgeTo],[AvailableFrom],[AvailableTo],[Cost],[RedemptionLimit],[RewardId],[Rrp],[CampaignRestriction],[RedemptionCodeType],[ExternalId],[ExternalRowVersion],[Discount],[FreeItemsCount],[Get],[MoneyOff],[MoneyOffSpent],[PayFor],[OfferReference],[SubscriptionPeriod],[DeletedAt],[IsDeleted]) \r\n"
				+ "  VALUES (101, 'Offer Automation SecondOne', 'Free', 1, 101, GETDATE(), null, null, null, null, 10, 50, GETDATE(), GETDATE(), 0.00, 'Unlimited', 101, 0.00, 'Generic', 'TLCRedemptionCode', null, 0 , null, null, null, null, null, null, null, null, null, null )\r\n"
				+ "  SET IDENTITY_INSERT [Offers] OFF";
		String LocalizedOffersFreeSecond = "SET IDENTITY_INSERT [LocalizedOffers] ON ---- 5 translations \r\n"
				+ "  INSERT INTO [LocalizedOffers] ([Id],[Name],[TermsOfOffer],[LanguageId],[OfferId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (101, 'Offer Automation Translation SecondOne', 'terms of offer', 1000, 101, GETDATE(), null, null, null, null, null, 0, null, null )\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedOffers] OFF";

		Statement stAdditionSecond = conn.createStatement();

		stAdditionSecond.addBatch(CategoriesSecond);
		stAdditionSecond.addBatch(LocalizedCategoriesSecond);
		stAdditionSecond.addBatch(SubcategoriesSecond);
		stAdditionSecond.addBatch(LocalizedSubcategoriesSecond);
		stAdditionSecond.addBatch(ExperiencesSecond);
		stAdditionSecond.addBatch(LocalizedExperienceSecond);
		stAdditionSecond.addBatch(RewardsSecond);
		stAdditionSecond.addBatch(LocalizedRewardsSecond);
		stAdditionSecond.addBatch(PartnersSecond);
		stAdditionSecond.addBatch(PartnerLocationsSecond);
		stAdditionSecond.addBatch(LocalizedPartnerLocationsSecond);

		stAdditionSecond.addBatch(OffersFreeSecond);
		stAdditionSecond.addBatch(LocalizedOffersFreeSecond);

		stAdditionSecond.executeBatch();
		
		
		//Third ch
		
		String CategoriesThird = "SET IDENTITY_INSERT Categories ON\r\n"
				+ "  INSERT INTO Categories ([Id],[Enabled],[ImageUrl],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Description],[LogoUrl],[Name],[ExternalId],[ExternalRowVersion],[BannerUrl],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 1, null, GETDATE(), null, null, null, null, 'description' , null, 'Category Automation', null, 0, null, null, null);\r\n"
				+ "  SET IDENTITY_INSERT Categories OFF" + "";
		String LocalizedCategoriesThird = "SET IDENTITY_INSERT [LocalizedCategories] ON\r\n"
				+ "  INSERT INTO LocalizedCategories ([Id],[Name],[Description],[LogoUrl],[CategoryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[BannerUrl],[ImageUrl],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (32, 'Category Translation ThirdOne ', 'description' , null, 102 , 1000, GETDATE(), null, null ,null, null, null, 0, null, null, null, null)\r\n"
				+ "   SET IDENTITY_INSERT [LocalizedCategories] OFF";
		String SubcategoriesThird = "SET IDENTITY_INSERT Subcategories ON\r\n"
				+ "   INSERT INTO Subcategories([Id],[Enabled],[ParentCategoryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[BannerUrl],[Description],[LogoUrl],[MainImageUrl],[Name],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "   VALUES (102, 1 , 102, GETDATE(), null, null, null, null, null, 'description', null, null, 'Subcategory Automation', null, 0, null, null)\r\n"
				+ "   SET IDENTITY_INSERT Subcategories OFF";
		String LocalizedSubcategoriesThird = "SET IDENTITY_INSERT [LocalizedSubcategories] ON\r\n"
				+ "  INSERT INTO [LocalizedSubcategories] ([Id],[Name],[Description],[LogoUrl],[MainImageUrl],[BannerUrl],[SubcategoryId],[LanguageId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (52, 'Subcategory Translation Third Test data ', 'description', null, null, null, 102, 1000, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedSubcategories] OFF";
		String ExperiencesThird = "SET IDENTITY_INSERT Experiences ON\r\n"
				+ "  INSERT INTO Experiences([Id],[SubcategoryId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[IsEnabled],[BannerUrl],[LogoUrl],[MainImageUrl],[Title],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 102, GETDATE(), null, null, null, null, 1, null, null, null, 'Experience-Automation', null, 0 , null, null )\r\n"
				+ "  SET IDENTITY_INSERT Experiences OFF";
		String LocalizedExperienceThird = "SET IDENTITY_INSERT LocalizedExperience ON\r\n"
				+ "  INSERT INTO LocalizedExperience ([Id],[Title],[LanguageId],[LogoUrl],[MainImageUrl],[BannerUrl],[ExperienceId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 'Experience Translation ThirdOne', 1000, null , null, null, 102, GETDATE(), null , null, null, null, null, 0, null, null )\r\n"
				+ "  SET IDENTITY_INSERT LocalizedExperience OFF";
		String RewardsThird = "SET IDENTITY_INSERT [Rewards] ON\r\n"
				+ "  INSERT INTO [Rewards] ([Id],[ExperienceId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Credits],[IsEnabled],[Title],[ExternalId],[ExternalRowVersion],[RewardReference],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 102, GETDATE(), null, null, null, null, 20, 1, 'Reward Automation', null, 0, null, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [Rewards] OFF";
		String LocalizedRewardsThird = "SET IDENTITY_INSERT [LocalizedRewards] ON\r\n"
				+ "  INSERT INTO [LocalizedRewards] ([Id],[Name],[TermsOfOffer],[LanguageId],[RewardId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 'Reward Translation ThirdOne', 'terms of offer', 1000, 102, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedRewards] OFF";
		String PartnersThird = "SET IDENTITY_INSERT [Partners] ON\r\n"
				+ "  INSERT INTO [Partners] ([Id],[Name],[Address],[City],[State],[Postcode],[Phone],[Email],[VatNo],[CompanyNo],[PartnerType],[IsCrossBorder],[LogoUrl],[MainImageUrl],[Notes],[IsEnabled],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[CountryId],[ExternalId],[ExternalRowVersion],[Address2],[Address3],[PartnerReference],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES(22, 'Automation Partner', 'address', 'city', 'state', '3333333333333' ,'MD-123', 'nokla@gmail.com' , '22222222', '22222222' , 'Independent', 1, null, null, null, 1, GETDATE(), null, null, null, null, 1000, null, 0, null, null, null, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [Partners] OFF";
		String PartnerLocationsThird = "SET IDENTITY_INSERT [PartnerLocations] ON\r\n"
				+ "  INSERT INTO [PartnerLocations] ([Id],[Name],[Address],[City],[County],[CountryId],[Region],[Postcode],[Phone],[Email],[Website],[OpeningHours],[LocationType],[DisabledAccess],[IsEnabled],[Radius],[PartnerId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[Address2],[Address3],[LogoUrl],[MainImageUrl],[Geolocation],[ExternalId],[ExternalRowVersion],[LocationReference],[AdministrativeUnit1Id],[AdministrativeUnit2Id],[AdministrativeUnit3Id],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 'Automation Location', 'address', 'city', 'county', 1000, 'state', 'postcode' , '12345678978' , 'email@mail.com', 'website.com', '14-18', 'Venue' , 'Unknown' , 1, 15, 21, GETDATE(), null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, null  )\r\n"
				+ "  SET IDENTITY_INSERT [PartnerLocations] OFF";
		String LocalizedPartnerLocationsThird = "SET IDENTITY_INSERT [LocalizedPartnerLocations] ON\r\n"
				+ "  INSERT INTO [LocalizedPartnerLocations] ([Id],[Name],[Address],[Address2],[Address3],[City],[County],[Country],[Region],[Postcode],[Phone],[Email],[Website],[OpeningHours],[LanguageId],[PartnerLocationId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (12, 'Automation Translation ThirdOne', 'Address 1 localization', 'Address 2 localization', 'Address 3 localization', 'city localization', 'county localization', 'country localization', 'state localization', 'MD-1234', '2134234213421', 'dfsdfsadf@test.com', 'website.com', '14-18', 1000, 102, GETDATE(), null, null, null, null, null, 0, null, null)\r\n"
				+ "    SET IDENTITY_INSERT [LocalizedPartnerLocations] OFF";
		String OffersFreeThird = "SET IDENTITY_INSERT [Offers] ON --- de 5 ori cu offers differit\r\n"
				+ "  INSERT INTO [Offers] ([Id],[Name],[Type],[IsEnabled],[PartnerLocationId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[AgeFrom],[AgeTo],[AvailableFrom],[AvailableTo],[Cost],[RedemptionLimit],[RewardId],[Rrp],[CampaignRestriction],[RedemptionCodeType],[ExternalId],[ExternalRowVersion],[Discount],[FreeItemsCount],[Get],[MoneyOff],[MoneyOffSpent],[PayFor],[OfferReference],[SubscriptionPeriod],[DeletedAt],[IsDeleted]) \r\n"
				+ "  VALUES (102, 'Offer Automation ThirdOne', 'Free', 1, 102, GETDATE(), null, null, null, null, 10, 50, GETDATE(), GETDATE(), 0.00, 'Unlimited', 102, 0.00, 'Generic', 'TLCRedemptionCode', null, 0 , null, null, null, null, null, null, null, null, null, null )\r\n"
				+ "  SET IDENTITY_INSERT [Offers] OFF";
		String LocalizedOffersFreeThird = "SET IDENTITY_INSERT [LocalizedOffers] ON ---- 5 translations \r\n"
				+ "  INSERT INTO [LocalizedOffers] ([Id],[Name],[TermsOfOffer],[LanguageId],[OfferId],[CreatedAt],[CreatedBy],[LastModifiedAt],[LastModifiedBy],[RowVersion],[ExternalId],[ExternalRowVersion],[DeletedAt],[IsDeleted])\r\n"
				+ "  VALUES (102, 'Offer Automation Translation ThirdOne', 'terms of offer', 1000, 102, GETDATE(), null, null, null, null, null, 0, null, null )\r\n"
				+ "  SET IDENTITY_INSERT [LocalizedOffers] OFF";

		Statement stAdditionThird = conn.createStatement();

		stAdditionThird.addBatch(CategoriesThird);
		stAdditionThird.addBatch(LocalizedCategoriesThird);
		stAdditionThird.addBatch(SubcategoriesThird);
		stAdditionThird.addBatch(LocalizedSubcategoriesThird);
		stAdditionThird.addBatch(ExperiencesThird);
		stAdditionThird.addBatch(LocalizedExperienceThird);
		stAdditionThird.addBatch(RewardsThird);
		stAdditionThird.addBatch(LocalizedRewardsThird);
		stAdditionThird.addBatch(PartnersThird);
		stAdditionThird.addBatch(PartnerLocationsThird);
		stAdditionThird.addBatch(LocalizedPartnerLocationsThird);

		stAdditionThird.addBatch(OffersFreeThird);
		stAdditionThird.addBatch(LocalizedOffersFreeThird);

		stAdditionThird.executeBatch();
		
		
		
	}
}
