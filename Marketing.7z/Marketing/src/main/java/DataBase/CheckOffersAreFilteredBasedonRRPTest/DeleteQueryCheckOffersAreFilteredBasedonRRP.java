package DataBase.CheckOffersAreFilteredBasedonRRPTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.Test;

public class DeleteQueryCheckOffersAreFilteredBasedonRRP { //9657

	
	@Test
	public void deleteQuery() throws ClassNotFoundException, SQLException {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Connection conn = DriverManager.getConnection(
				prop.getProperty("serverDatabase"),
				prop.getProperty("UserId"),
				prop.getProperty("passwordd"));
		conn.nativeSQL("Clients");
		
		System.out.println("Connected successfully");

		Statement st = conn.createStatement();
		String BespokeAdditionalValue = "delete from [OfferCampaigns]  where OfferId = 100";
		String Listings = "delete from [Listings] where id = 1000";
		String Websites = "delete from [Websites]  where id = 1000";
		String Campaigns = "delete from [Campaigns]  where id = 100";
		String Clients = "delete from [Clients]  where id = 100";
		String CountryLanguages = "delete from [CountryLanguages]  where CountryId = 1000";
		String Countries = "delete from [Countries]  where id = 1000";
		String Languages = "delete from  [Languages]  where id = 1000";
		
		st.addBatch(BespokeAdditionalValue);
		st.addBatch(Listings);
		st.addBatch(Websites);
		st.addBatch(Campaigns);
		st.addBatch(Clients);
		st.addBatch(CountryLanguages);
		st.addBatch(Countries);
		st.addBatch(Languages);

		st.executeBatch();

		Statement stAddition = conn.createStatement();

		String Partners = "delete from [Partners]   where id = 20";
		String LocalizedRewards = "delete from [LocalizedRewards]   where id = 100";
		String Rewards = "delete from [Rewards]   where id = 100";
		String LocalizedExperience = "delete from [LocalizedExperience ]   where id = 100";
		String Experiences = "delete from [Experiences ]  where id = 100";

		String LocalizedSubcategories = "delete from [LocalizedSubcategories]   where id = 50";
		String Subcategories = "delete from [Subcategories ]   where id = 100";
		String LocalizedCategories = "delete from [LocalizedCategories]   where id = 30";
		String Categories = "delete from [Categories ]   where id = 100";

		String PartnerLocations= "delete from [PartnerLocations]   where id = 100";
		String LocalizedPartnerLocations = "delete from [LocalizedPartnerLocations]  where id = 10";
		
		
		String Offers0 = "delete from [Offers]  where id = 100";
		String Offers1500 = "delete from [Offers]  where id = 101";
		String Offers9999 = "delete from [Offers]  where id = 102";
		
		
		String LocalizedOffers0 = "delete from [LocalizedOffers]  where id = 100";
		String LocalizedOffers1500 = "delete from [LocalizedOffers]  where id = 101";
		String LocalizedOffers9999 = "delete from [LocalizedOffers]  where id = 102";
		
		
		

		stAddition.addBatch(LocalizedOffers0);
		stAddition.addBatch(LocalizedOffers1500);
		stAddition.addBatch(LocalizedOffers9999);
		
		
		stAddition.addBatch(Offers0);
		stAddition.addBatch(Offers1500);
		stAddition.addBatch(Offers9999);
		
		
		
		
		stAddition.addBatch(LocalizedPartnerLocations);
		stAddition.addBatch(PartnerLocations);
		stAddition.addBatch(Partners);
		stAddition.addBatch(LocalizedRewards);
		stAddition.addBatch(Rewards);
		stAddition.addBatch(LocalizedExperience);
		stAddition.addBatch(Experiences);
		stAddition.addBatch(LocalizedSubcategories);
		stAddition.addBatch(Subcategories);
		stAddition.addBatch(LocalizedCategories);
		stAddition.addBatch(Categories);
		
		
		stAddition.executeBatch();
		
		
		
		
	}
}
