package DataBase.CheckOffersAreFilteredBasedOnCampaignRestrictions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.Test;

public class DeleteQueryCheckOffersAreFilteredBasedOnCampaignRestrictions { // TC nr 9655

	@Test
	public void deleteQuery() throws ClassNotFoundException, SQLException {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Connection conn = DriverManager.getConnection(
				prop.getProperty("serverDatabase"),
				prop.getProperty("UserId"),
				prop.getProperty("passwordd"));
		conn.nativeSQL("Clients");
		
		System.out.println("Connected successfully");

		Statement st = conn.createStatement();
		String BespokeAdditionalValue = "delete from [OfferCampaigns]  where OfferId = 100";
		String Listings = "delete from [Listings] where id = 1000";
		String Websites = "delete from [Websites]  where id = 1000";
		String Campaigns = "delete from [Campaigns]  where id = 100";
		String Clients = "delete from [Clients]  where id = 100";
		String CountryLanguages = "delete from [CountryLanguages]  where CountryId = 1000";
		String Countries = "delete from [Countries]  where id = 1000";
		String Languages = "delete from  [Languages]  where id = 1000";
		
		st.addBatch(BespokeAdditionalValue);
		st.addBatch(Listings);
		st.addBatch(Websites);
		st.addBatch(Campaigns);
		st.addBatch(Clients);
		st.addBatch(CountryLanguages);
		st.addBatch(Countries);
		st.addBatch(Languages);

		st.executeBatch();

		Statement stAddition = conn.createStatement();

		String Partners = "delete from [Partners]   where id = 20";
		String LocalizedRewards = "delete from [LocalizedRewards]   where id = 100";
		String Rewards = "delete from [Rewards]   where id = 100";
		String LocalizedExperience = "delete from [LocalizedExperience ]   where id = 100";
		String Experiences = "delete from [Experiences ]  where id = 100";
		String LocalizedSubcategories = "delete from [LocalizedSubcategories]   where id = 50";
		String Subcategories = "delete from [Subcategories ]   where id = 100";
		String LocalizedCategories = "delete from [LocalizedCategories]   where id = 30";
		String Categories = "delete from [Categories ]   where id = 100";
		String PartnerLocationsVenue = "delete from [PartnerLocations]   where id = 100";
		String LocalizedPartnerLocationsVenue = "delete from [LocalizedPartnerLocations]  where id = 10";
		String OffersFreeVenue = "delete from [Offers]  where id = 100";
		String LocalizedOffersFreeVenue = "delete from [LocalizedOffers]  where id = 100";
		
		

		stAddition.addBatch(LocalizedOffersFreeVenue);
		stAddition.addBatch(OffersFreeVenue);
		stAddition.addBatch(LocalizedPartnerLocationsVenue);
		stAddition.addBatch(PartnerLocationsVenue);

		stAddition.addBatch(Partners);
		stAddition.addBatch(LocalizedRewards);
		stAddition.addBatch(Rewards);
		stAddition.addBatch(LocalizedExperience);
		stAddition.addBatch(Experiences);
		stAddition.addBatch(LocalizedSubcategories);
		stAddition.addBatch(Subcategories);
		stAddition.addBatch(LocalizedCategories);
		stAddition.addBatch(Categories);
		
		
		stAddition.executeBatch();
		
		//delete second ch
		
		Statement stAdditionSecond = conn.createStatement();

		String LocalizedOffersFreeSecond = "delete from [LocalizedOffers]  where id = 101";
		String OffersFreeSecond = "delete from [Offers]  where id = 100";
		String LocalizedPartnerLocationsSecond = "delete from [LocalizedPartnerLocations]  where id = 11";
		String PartnerLocationsSecond = "delete from [PartnerLocations]   where id = 101";
		String PartnersSecond = "delete from [Partners]   where id = 21";
		String LocalizedRewardsSecond = "delete from [LocalizedRewards]   where id = 101";
		String RewardsSecond = "delete from [Rewards]   where id = 101";
		String LocalizedExperienceSecond = "delete from [LocalizedExperience ]   where id = 101";
		String ExperiencesSecond = "delete from [Experiences ]  where id = 101";
		String LocalizedSubcategoriesSecond = "delete from [LocalizedSubcategories]   where id = 51";
		String SubcategoriesSecond = "delete from [Subcategories ]   where id = 101";
		String LocalizedCategoriesSecond = "delete from [LocalizedCategories]   where id = 31";
		String CategoriesSecond = "delete from [Categories ]   where id = 101";

		stAdditionSecond.addBatch(LocalizedOffersFreeSecond);
		stAdditionSecond.addBatch(OffersFreeSecond);
		stAdditionSecond.addBatch(LocalizedPartnerLocationsSecond);
		stAdditionSecond.addBatch(PartnerLocationsSecond);
		stAdditionSecond.addBatch(PartnersSecond);
		stAdditionSecond.addBatch(LocalizedRewardsSecond);
		stAdditionSecond.addBatch(RewardsSecond);
		stAdditionSecond.addBatch(LocalizedExperienceSecond);
		stAdditionSecond.addBatch(ExperiencesSecond);
		stAdditionSecond.addBatch(LocalizedSubcategoriesSecond);
		stAdditionSecond.addBatch(SubcategoriesSecond);
		stAdditionSecond.addBatch(LocalizedCategoriesSecond);
		stAdditionSecond.addBatch(CategoriesSecond);

		stAdditionSecond.executeBatch();
		
		//delete third ch
		
		Statement stAdditionThird = conn.createStatement();

		String LocalizedOffersFreeThird = "delete from [LocalizedOffers]  where id = 102";
		String OffersFreeThird = "delete from [Offers]  where id = 102";
		String LocalizedPartnerLocationsThird = "delete from [LocalizedPartnerLocations]  where id = 12";
		String PartnerLocationsThird = "delete from [PartnerLocations]   where id = 102";
		String PartnersThird = "delete from [Partners]   where id = 22";
		String LocalizedRewardsThird = "delete from [LocalizedRewards]   where id = 102";
		String RewardsThird = "delete from [Rewards]   where id = 102";
		String LocalizedExperienceThird = "delete from [LocalizedExperience ]   where id = 102";
		String ExperiencesThird = "delete from [Experiences ]  where id = 102";
		String LocalizedSubcategoriesThird = "delete from [LocalizedSubcategories]   where id = 52";
		String SubcategoriesThird = "delete from [Subcategories ]   where id = 102";
		String LocalizedCategoriesThird = "delete from [LocalizedCategories]   where id = 32";
		String CategoriesThird = "delete from [Categories ]   where id = 102";

		stAdditionThird.addBatch(LocalizedOffersFreeThird);
		stAdditionThird.addBatch(OffersFreeThird);
		stAdditionThird.addBatch(LocalizedPartnerLocationsThird);
		stAdditionThird.addBatch(PartnerLocationsThird);
		stAdditionThird.addBatch(PartnersThird);
		stAdditionThird.addBatch(LocalizedRewardsThird);
		stAdditionThird.addBatch(RewardsThird);
		stAdditionThird.addBatch(LocalizedExperienceThird);
		stAdditionThird.addBatch(ExperiencesThird);
		stAdditionThird.addBatch(LocalizedSubcategoriesThird);
		stAdditionThird.addBatch(SubcategoriesThird);
		stAdditionThird.addBatch(LocalizedCategoriesThird);
		stAdditionThird.addBatch(CategoriesThird);

		stAdditionThird.executeBatch();
		
		
	}
}
