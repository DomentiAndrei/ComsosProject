package DataBase.CheckOffersAreFilteredBasedOnLocationType;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.Test;

public class DeleteQueryCheckOffersAreFilteredBasedOnLocationType {

	@Test
	public void deleteQuery() throws ClassNotFoundException, SQLException {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Connection conn = DriverManager.getConnection(
				prop.getProperty("serverDatabase"),
				prop.getProperty("UserId"),
				prop.getProperty("passwordd"));
		conn.nativeSQL("Clients");
		
		System.out.println("Connected successfully");

		Statement st = conn.createStatement();

		String Listings = "delete from [Listings] where id = 1000";
		String Websites = "delete from [Websites]  where id = 1000";
		String Campaigns = "delete from [Campaigns]  where id = 100";
		String Clients = "delete from [Clients]  where id = 100";
		String CountryLanguages = "delete from [CountryLanguages]  where CountryId = 1000";
		String Countries = "delete from [Countries]  where id = 1000";
		String Languages = "delete from  [Languages]  where id = 1000";

		st.addBatch(Listings);
		st.addBatch(Websites);
		st.addBatch(Campaigns);
		st.addBatch(Clients);
		st.addBatch(CountryLanguages);
		st.addBatch(Countries);
		st.addBatch(Languages);

		st.executeBatch();

		Statement stAddition = conn.createStatement();

		
		
		String Partners = "delete from [Partners]   where id = 20";
		String LocalizedRewards = "delete from [LocalizedRewards]   where id = 100";
		String Rewards = "delete from [Rewards]   where id = 100";
		String LocalizedExperience = "delete from [LocalizedExperience ]   where id = 100";
		String Experiences = "delete from [Experiences ]  where id = 100";
		
		
		String LocalizedSubcategories = "delete from [LocalizedSubcategories]   where id = 50";
		String Subcategories = "delete from [Subcategories ]   where id = 100";
		String LocalizedCategories = "delete from [LocalizedCategories]   where id = 30";
		String Categories = "delete from [Categories ]   where id = 100";

		
		String PartnerLocationsVenue = "delete from [PartnerLocations]   where id = 100";
		String PartnerLocationsMobile = "delete from [PartnerLocations]   where id = 101";
		String PartnerLocationsOnline = "delete from [PartnerLocations]   where id = 102";
		String PartnerLocationsVenueNotListed = "delete from [PartnerLocations]   where id = 103";
		String PartnerLocationsDelivery = "delete from [PartnerLocations]   where id = 104";
		
		String LocalizedPartnerLocationsVenue = "delete from [LocalizedPartnerLocations]  where id = 10";
		String LocalizedPartnerLocationsMobile = "delete from [LocalizedPartnerLocations]  where id = 11";
		String LocalizedPartnerLocationsOnline = "delete from [LocalizedPartnerLocations]  where id = 12";
		String LocalizedPartnerLocationsVenueNotListed = "delete from [LocalizedPartnerLocations]  where id = 13";
		String LocalizedPartnerLocationsDelivery = "delete from [LocalizedPartnerLocations]  where id = 14";
		
		String OffersFreeVenue = "delete from [Offers]  where id = 100";
		String OffersFreeMobile = "delete from [Offers]  where id = 101";
		String OffersFreeOnline = "delete from [Offers]  where id = 102";
		String OffersFreeVenueNotListed = "delete from [Offers]  where id = 103";
		String OffersFreeDelivery = "delete from [Offers]  where id = 104";
		
		String LocalizedOffersFreeVenue = "delete from [LocalizedOffers]  where id = 100";
		String LocalizedOffersFreeMobile = "delete from [LocalizedOffers]  where id = 101";
		String LocalizedOffersFreeOnline = "delete from [LocalizedOffers]  where id = 102";
		String LocalizedOffersFreeVenueNotListed = "delete from [LocalizedOffers]  where id = 103";
		String LocalizedOffersFreeDelivery = "delete from [LocalizedOffers]  where id = 104";
		
		stAddition.addBatch(LocalizedOffersFreeVenue);
		stAddition.addBatch(LocalizedOffersFreeMobile);
		stAddition.addBatch(LocalizedOffersFreeOnline);
		stAddition.addBatch(LocalizedOffersFreeVenueNotListed);
		stAddition.addBatch(LocalizedOffersFreeDelivery);
	
		
		stAddition.addBatch(OffersFreeVenue);
		stAddition.addBatch(OffersFreeMobile);
		stAddition.addBatch(OffersFreeOnline);
		stAddition.addBatch(OffersFreeVenueNotListed);
		stAddition.addBatch(OffersFreeDelivery);
		
		
		stAddition.addBatch(LocalizedPartnerLocationsVenue);
		stAddition.addBatch(LocalizedPartnerLocationsMobile);
		stAddition.addBatch(LocalizedPartnerLocationsOnline);
		stAddition.addBatch(LocalizedPartnerLocationsVenueNotListed);
		stAddition.addBatch(LocalizedPartnerLocationsDelivery);
		
		
		stAddition.addBatch(PartnerLocationsVenue);
		stAddition.addBatch(PartnerLocationsMobile);
		stAddition.addBatch(PartnerLocationsOnline);
		stAddition.addBatch(PartnerLocationsVenueNotListed);
		stAddition.addBatch(PartnerLocationsDelivery);
		
		
		
		
		
		stAddition.addBatch(Partners);
		stAddition.addBatch(LocalizedRewards);
		stAddition.addBatch(Rewards);
		stAddition.addBatch(LocalizedExperience);
		stAddition.addBatch(Experiences);
		stAddition.addBatch(LocalizedSubcategories);
		stAddition.addBatch(Subcategories);
		stAddition.addBatch(LocalizedCategories);
		stAddition.addBatch(Categories);
		stAddition.executeBatch();

	}
}
