package DataBase.CheckOffersAreFilteredBasedOnListingDefaultCountry;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.Test;

public class DeleteQueryCheckOffersAreFilteredBasedOnListingDefaultCountry { // 9680

	@Test
	public void deleteQuery() throws ClassNotFoundException, SQLException {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		File file = new File("..\\Marketing\\config.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Connection conn = DriverManager.getConnection(
				prop.getProperty("serverDatabase"),
				prop.getProperty("UserId"),
				prop.getProperty("passwordd"));
		conn.nativeSQL("Clients");
		
		System.out.println("Connected successfully");

		Statement st = conn.createStatement();
		
		String Countries = "delete from [Countries]  where id = 1000";
		String BespokeAdditionalValue = "delete from [OfferCampaigns]  where OfferId = 100";
		String Listings = "delete from [Listings] where id = 1000";
		String Websites = "delete from [Websites]  where id = 1000";
		String Campaigns = "delete from [Campaigns]  where id = 100";
		String Clients = "delete from [Clients]  where id = 100";
		String CountryLanguages = "delete from [CountryLanguages]  where CountryId = 1000";
		String Languages = "delete from  [Languages]  where id = 1000";

		st.addBatch(BespokeAdditionalValue);
		st.addBatch(Listings);
		st.addBatch(Websites);
		st.addBatch(Campaigns);
		st.addBatch(Clients);
		st.addBatch(CountryLanguages);
		st.addBatch(Countries);
		st.addBatch(Languages);

		st.executeBatch();

		Statement stAddition = conn.createStatement();

		String Partners = "delete from [Partners]   where id = 20";
		String LocalizedRewards = "delete from [LocalizedRewards]   where id = 100";
		String Rewards = "delete from [Rewards]   where id = 100";
		String LocalizedExperience = "delete from [LocalizedExperience ]   where id = 100";
		String Experiences = "delete from [Experiences ]  where id = 100";
		String LocalizedSubcategories = "delete from [LocalizedSubcategories]   where id = 50";
		String Subcategories = "delete from [Subcategories ]   where id = 100";
		String LocalizedCategories = "delete from [LocalizedCategories]   where id = 30";
		String Categories = "delete from [Categories ]   where id = 100";
		String PartnerLocationsVenue = "delete from [PartnerLocations]   where id = 100";
		String LocalizedPartnerLocationsVenue = "delete from [LocalizedPartnerLocations]  where id = 10";
		String OffersFreeVenue = "delete from [Offers]  where id = 100";
		String LocalizedOffersFreeVenue = "delete from [LocalizedOffers]  where id = 100";

		stAddition.addBatch(PartnerLocationsVenue);
		stAddition.addBatch(LocalizedOffersFreeVenue);
		stAddition.addBatch(OffersFreeVenue);
		stAddition.addBatch(LocalizedPartnerLocationsVenue);
		stAddition.addBatch(Partners);
		stAddition.addBatch(LocalizedRewards);
		stAddition.addBatch(Rewards);
		stAddition.addBatch(LocalizedExperience);
		stAddition.addBatch(Experiences);
		stAddition.addBatch(LocalizedSubcategories);
		stAddition.addBatch(Subcategories);
		stAddition.addBatch(LocalizedCategories);
		stAddition.addBatch(Categories);

		stAddition.executeBatch();

		// Second Value Deleted

		Statement st2 = conn.createStatement();
		String BespokeAdditionalValue2 = "delete from [OfferCampaigns]  where OfferId = 101";
		String Listings2 = "delete from [Listings] where id = 1001";
		String Websites2 = "delete from [Websites]  where id = 1001";
		String Campaigns2 = "delete from [Campaigns]  where id = 101";
		String Clients2 = "delete from [Clients]  where id = 101";
		String CountryLanguages2 = "delete from [CountryLanguages]  where CountryId = 1001";
		String Countries2 = "delete from [Countries]  where id = 1001";
		String Languages2 = "delete from  [Languages]  where id = 1001";

		st2.addBatch(BespokeAdditionalValue2);
		st2.addBatch(Listings2);
		st2.addBatch(Websites2);
		st2.addBatch(Campaigns2);
		st2.addBatch(Clients2);
		st2.addBatch(CountryLanguages2);
		st2.addBatch(Countries2);
		st2.addBatch(Languages2);

		st2.executeBatch();

		Statement stAddition2 = conn.createStatement();

		String LocalizedOffers2 = "delete from [LocalizedOffers]  where id = 101";
		String Offers2 = "delete from [Offers]  where id = 101";
		String LocalizedPartnerLocations2 = "delete from [LocalizedPartnerLocations]  where id = 11";
		String PartnerLocations2 = "delete from [PartnerLocations]   where id = 101";
		String Partners2 = "delete from [Partners]   where id = 21";
		String LocalizedRewards2 = "delete from [LocalizedRewards]   where id = 101";
		String Rewards2 = "delete from [Rewards]   where id = 101";
		String LocalizedExperienceSecond = "delete from [LocalizedExperience ]   where id = 101";
		String Experiences2 = "delete from [Experiences ]  where id = 101";
		String LocalizedSubcategories2 = "delete from [LocalizedSubcategories]   where id = 51";
		String Subcategories2 = "delete from [Subcategories ]   where id = 101";
		String LocalizedCategories2 = "delete from [LocalizedCategories]   where id = 31";
		String Categories2 = "delete from [Categories ]   where id = 101";

	
		stAddition2.addBatch(LocalizedOffers2);
		stAddition2.addBatch(Offers2);
		stAddition2.addBatch(LocalizedPartnerLocations2);
		stAddition2.addBatch(PartnerLocations2);
		stAddition2.addBatch(Partners2);
		stAddition2.addBatch(LocalizedRewards2);
		stAddition2.addBatch(Rewards2);
		stAddition2.addBatch(LocalizedExperienceSecond);
		stAddition2.addBatch(LocalizedExperienceSecond);
		stAddition2.addBatch(Experiences2);
		stAddition2.addBatch(LocalizedSubcategories2);
		stAddition2.addBatch(Subcategories2);
		stAddition2.addBatch(LocalizedCategories2);
		stAddition2.addBatch(Categories2);

		

		stAddition2.executeBatch();

	}
}
