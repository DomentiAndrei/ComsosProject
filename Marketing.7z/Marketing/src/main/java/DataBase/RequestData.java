package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RequestData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		Connection conn = DriverManager.getConnection("jdbc:sqlserver://ukz-cosmos-test-sql.database.windows.net:1433;database=ukz-partport-test-sdb",
				"ukz-partport-test-sdb", "jw5>3BXZ");
		conn.nativeSQL("Clients");
		System.out.println("Connected successfully");

		Statement st = conn.createStatement();

		String query = "delete from  [Languages]  where id = 1000";

		st.executeQuery(query);
		ResultSet rs = st.executeQuery(query);
		while (rs.next()) {

			System.out.println(rs.getString(1) + " " + rs.getString(2) + " "  + rs.getString(3) + rs.getString(4) + " " + rs.getString(5));

		}

	}
}
