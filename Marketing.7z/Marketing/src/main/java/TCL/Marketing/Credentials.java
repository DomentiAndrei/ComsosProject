package TCL.Marketing;

public class Credentials {

	
	static String USERNAME = "Dev-Cosmos-GlobalAdmin@tlcmarketing.com";
	static String PASSWORD = "Wucu5990!!";	
	
	public static void logIn() {
		
		
			
		
	}
}
