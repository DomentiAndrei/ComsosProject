package TCL.Marketing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpBarSide {

	WebDriver driver;
	@FindBy (xpath = "//ngx-header/div[1]/div[1]/a[2]")
	WebElement Logo;
	
	@FindBy (xpath = "//ngx-header/div[1]/nb-select[1]/button[1]")
	WebElement BackGroundColor;
	
	@FindBy (xpath = "//nb-select[@placeholder='Select Country']")
	WebElement dropDownCountru;
	
	@FindBy (xpath = "//div[contains(text(),'Andrei Domenti')]")
	WebElement ProfileLogOut;
	
	@FindBy (xpath = "//nb-option[@id='nb-option-5']")
	WebElement automation;
	
	public UpBarSide(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void clickDropDownCountru() {
		dropDownCountru.click(); 
	}
	
	public void clickAutomation() {
		automation.click(); 
	}
	
}
