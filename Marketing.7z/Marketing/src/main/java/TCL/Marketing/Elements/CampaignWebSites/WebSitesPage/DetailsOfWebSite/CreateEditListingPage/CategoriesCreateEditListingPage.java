package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CategoriesCreateEditListingPage {

	WebDriver driver;
	@FindBy(xpath  = "//p[contains(text(),'Categories')]")
    WebElement categoriesButton ;
	
	@FindBy(xpath  = "body.nb-theme-default.pace-done:nth-child(5) ngx-pages.ng-star-inserted:nth-child(2) div.scrollable-container div.layout div.layout-container div.content div.columns ngx-components.ng-star-inserted:nth-child(2) ngx-by-rewards.ng-star-inserted:nth-child(2) div.mt-2 nb-stepper.vertical:nth-child(1) div.step-content nb-card.ng-star-inserted div.grid-container div.mt-4 div.row.mt-6.ng-star-inserted:nth-child(14) div.col-sm-9 li.ng-star-inserted:nth-child(1) nb-checkbox.status-primary.nb-transition label.label span.custom-checkbox.checked nb-icon.ng-star-inserted svg:nth-child(1) > use:nth-child(2)")
    WebElement ALLCategoryRetestingEnglTranslationAddedBack ;
	
	@FindBy(xpath  = "//a[contains(text(),'Skip to Results ')]")
    WebElement skipToResults  ;
	
	public CategoriesCreateEditListingPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void clickCategoriesButton() {
		categoriesButton.click();
	}
	public void clickALLCategoryRetestingEnglTranslationAddedBack() {
		ALLCategoryRetestingEnglTranslationAddedBack.click();
	}
	public void clickSkipToResults() {
		skipToResults.click();
	}
	
	
}
