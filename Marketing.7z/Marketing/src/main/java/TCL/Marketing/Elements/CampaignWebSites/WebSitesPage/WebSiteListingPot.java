package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class WebSiteListingPot extends Boss {

	WebDriver driver;

	@FindBy(xpath = "//p[contains(text(),'Edit Rewards')]")
	WebElement editRewardsButton;

	@FindBy(xpath = "")
	WebElement categoriesButton;
	
	@FindBy(xpath = "//nb-card-body/div[1]/div[1]/div[4]/nb-icon[1]/*[1]")
	WebElement addNewPot;

	@FindBy(xpath = "//button[contains(text(),'close')]")
	WebElement closeButton;

	@FindBy(xpath = "//*[contains(text(),' Reward Pot ')]")
	WebElement nameOfReward;

	@FindBy(xpath = "//p[contains(text(),'Last updated:')]")
	WebElement lastUpdated;
	
	@FindBy (xpath = "//nb-card-body//div[3]/div[1]/div[1]/nb-icon[1]/*[1]")
	WebElement binButton;
	
	@FindBy (xpath = "//button[contains(text(),'Delete Pot')]")
	WebElement deletePOTfromPopUp;

	public WebSiteListingPot(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	public void clickDeletePOTfromPopUp() {
		deletePOTfromPopUp.click();
		log.info("deletePOTfromPopUp clicked");
	}
	
	public void clickBinButton() {
		binButton.click();
		log.info("binButton clicked");
	}
	public void clickEditRewardsButton() {
		editRewardsButton.click();
		log.info("click EDIT rewards button was clicked");
	}
	public void clickCloseButton() {
		closeButton.click();
		log.info("closeButton clicked");
	}
	public void clickAddNewPot() {
		addNewPot.click();
		log.info("AddNewPot clicked");
	}
	
	@FindBy(xpath = "//nb-card-body//div[3]//div[2]/div[2]/div[1]/p[1]")
	WebElement numberofOffers;
	
	@FindBy(xpath = "//nb-card-body//div[3]//div[2]/div[2]/div[2]/p[1]")
	WebElement numberofPartners;
	
	@FindBy(xpath = "//nb-card-body//div[3]//div[2]/div[2]/div[3]/p[1]")
	WebElement numberofRewards;
	
	@FindBy(xpath = "//nb-card-body//div[3]//div[2]/div[2]/div[4]/p[1]")
	WebElement numberofLocations;
	
	public void checkNumberofOffers(String amountOffer) {
		Assert.assertEquals(numberofOffers.getText(), amountOffer);
		log.info("numberofOffers checked");
	}
	public void checknumberofPartners(String amountPartner) {
		Assert.assertEquals(numberofPartners.getText(),amountPartner );
		log.info("numberofPartners checked");
	}
	public void checknumberofRewards(String amountRewards) {
		Assert.assertEquals(numberofRewards.getText(),amountRewards);
		log.info("numberofRewards checked");
	}
	public void checknumberofLocations(String amountLocation) {
		Assert.assertEquals(numberofLocations.getText(), amountLocation);
		log.info("numberofLocations checked");
		
	}	
		@FindBy(xpath = "//body[1]//div[1]/div[1]/div[1]/div[1]/div[1]/p[1]")
		WebElement numberofOffersGeneralCounties;
		
		@FindBy(xpath = "//body[1]//div[1]/div[1]/div[1]/div[1]/div[2]/p[1]")
		WebElement numberofPartnersGeneralCounties;
		
		@FindBy(xpath = "//body[1]//div[1]/div[1]/div[1]/div[1]/div[3]/p[1]")
		WebElement numberofRewardsGeneralCounties;
		
		@FindBy(xpath = "//body[1]//div[1]/div[1]/div[1]/div[1]/div[4]/p[1]")
		WebElement numberofLocationsGeneralCounties;
		
		public void checkNumberofOffersGeneralCounties(String amountOfferGeneralCounties) {
			Assert.assertEquals(numberofOffersGeneralCounties.getText(), amountOfferGeneralCounties);
			log.info("numberofOffersGeneralCounties checked");
		}
		public void checknumberofPartnersGeneralCounties(String amountPartnerGeneralCounties) {
			Assert.assertEquals(numberofPartnersGeneralCounties.getText(),amountPartnerGeneralCounties );
			log.info("numberofPartnersGeneralCounties checked");
		}
		public void checknumberofRewardsGeneralCounties(String amountRewardsGeneralCounties) {
			Assert.assertEquals(numberofRewardsGeneralCounties.getText(),amountRewardsGeneralCounties);
			log.info("numberofRewardsGeneralCounties checked");
		}
		public void checknumberofLocationsGeneralCounties(String amountLocationGeneralCounties) {
			Assert.assertEquals(numberofLocationsGeneralCounties.getText(), amountLocationGeneralCounties);
			log.info("numberofLocationsGeneralCounties checked");
			
		}
	
	public void checkNameOfReward() {
		Assert.assertEquals(nameOfReward.getText(), "Reward Pot");
		log.info("Reward Pot checked");
	}
	public void checkLastUpdated() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
		LocalDateTime now = LocalDateTime.now();  
		Assert.assertEquals(lastUpdated.getText(), "Last updated: " + dtf.format(now));
	}
	

}
