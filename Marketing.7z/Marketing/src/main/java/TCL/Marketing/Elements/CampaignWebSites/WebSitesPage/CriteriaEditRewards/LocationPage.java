package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class LocationPage extends Boss {

	WebDriver driver;

	@FindBy(xpath = "//span[contains(text(),'All')]")
	WebElement allCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Mobile')]")
	WebElement mobileCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Venue')]")
	WebElement venueCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Delivery')]")
	WebElement deliveryCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Online')]")
	WebElement onlineCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Venue not listed')]")
	WebElement venueNotListedCheckBox;

	@FindBy(xpath = "//input[@id='search']")
	WebElement searchFieldOnLocationScreen;

	@FindBy(xpath = "//button[@status='primary']")
	WebElement searchButtononLocationScreen;

	public LocationPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void checktICkAllCheckBox() {
		boolean tICkAllCheckBox = allCheckBox.isEnabled();
		Assert.assertEquals(true, tICkAllCheckBox);
		log.info("Location ALL checkbox checked");
	}

	public void checkTickMobileCheckBox() {
		boolean tickMobileCheckBox = mobileCheckBox.isEnabled();
		Assert.assertEquals(true, tickMobileCheckBox);
		log.info("Location Mobile checkbox checked");
	}

	public void checkTickVenueCheckBx() {
		boolean tickVenueCheckBox = venueCheckBox.isEnabled();
		Assert.assertEquals(true, tickVenueCheckBox);
		log.info("Location Venue checkbox checked");
	}

	public void checkTickDeliVeryCheckBox() {
		boolean tickdeliveryCheckBox = deliveryCheckBox.isEnabled();
		Assert.assertEquals(true, tickdeliveryCheckBox);
		log.info("Location Delivery checkbox checked");
	}

	public void checkTickOnlineCheckBox() {
		boolean tickOnlineCheckBox = onlineCheckBox.isEnabled();
		Assert.assertEquals(true, tickOnlineCheckBox);
		log.info("Location Online checkbox checked");
	}

	public void checkVenueNotListedCheckBox() {
		boolean tickVenueNotListedCheckBox = venueNotListedCheckBox.isEnabled();
		Assert.assertEquals(true, tickVenueNotListedCheckBox);
		log.info("Location VenueNotListed checkbox checked");
	}
	public void clickAllCheckBox() {
		allCheckBox.click();
		log.info("All location clicked");
	}
	public void clickMobileCheckBox() {
		mobileCheckBox.click();
		log.info("Mobile clicked");
	}
	public void clickVenueCheckBox() {
		venueCheckBox.click();
		log.info("Venue clicked");
	}
	public void clickDeliveryCheckBox() {
		deliveryCheckBox.click();
		log.info("Delivery clicked");
	}

	public void clickOnlineCheckBox() {
		onlineCheckBox.click();
		log.info("Online clicked");
	}
	public void clickVenueNotListedCheckBox() {
		venueNotListedCheckBox.click();
		log.info("VenueNotListed clicked");
	}

	public void checkAllCheckBoxes() {
		this.checktICkAllCheckBox();
		this.checkTickMobileCheckBox();
		this.checkTickVenueCheckBx();
		this.checkTickDeliVeryCheckBox();
		this.checkTickOnlineCheckBox();
		this.checkVenueNotListedCheckBox();
	}

}
