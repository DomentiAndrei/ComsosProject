package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class RewarsResultOfLestingPot extends Boss{

	
	WebDriver driver;
	@FindBy (xpath = "//div[contains(text(),'Offer Automation Translation Delivery')]")
	WebElement checkDelivery;
	
	@FindBy (xpath = "//div[contains(text(),'Offer Automation Translation Mobile')]")
	WebElement checkMobile;
	
	@FindBy (xpath = "//div[contains(text(),'Offer Automation Translation Online')]")
	WebElement checkOnline;
	
	@FindBy (xpath = "//div[contains(text(),'Offer Automation Translation Venue') and not(contains(text(),'NotListed'))]")
	WebElement checkVenue;
	
	@FindBy (xpath = "//div[contains(text(),'Offer Automation Translation VenueNotListed')]")
	WebElement checkVenueNotListed;
	
	@FindBy(xpath = "//tbody/tr[1]/td[8]/nb-actions[1]/nb-action[1]/a[1]")
	WebElement editButton1;
	
	@FindBy(xpath = "//tbody/tr[2]/td[8]/nb-actions[1]/nb-action[1]/a[1]")
	WebElement editButton2;
	
	@FindBy(xpath = "//nb-accordion-item[2]//table[1]/tbody[1]/tr[1]/td[8]/nb-actions[1]/nb-action[1]")
	WebElement editButton2ForTCNR9655;
	
	@FindBy(xpath = "//nb-accordion-item[3]//table[1]/tbody[1]/tr[1]/td[8]/nb-actions[1]/nb-action[1]")
	WebElement editButton3ForTCNR9655;
	
	
	@FindBy(xpath = "//tbody/tr[3]/td[8]/nb-actions[1]/nb-action[1]/a[1]")
	WebElement editButton3;
	
	@FindBy(xpath = "//tbody/tr[4]/td[8]/nb-actions[1]/nb-action[1]/a[1]")
	WebElement editButton4;
	
	@FindBy(xpath = "//tbody/tr[5]/td[8]/nb-actions[1]/nb-action[1]/a[1]")
	WebElement editButton5;
	
	public RewarsResultOfLestingPot(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void checkDelivery() {
		Assert.assertEquals(checkDelivery.getText().trim(), "Offer Automation Translation Delivery");
		log.info("Delivery checked - present");
	}
	public void checkMobile() {
		Assert.assertEquals(checkMobile.getText().trim(), "Offer Automation Translation Mobile");
		log.info("Mobile checked - present");
	}
	public void checkOnline() {
		Assert.assertEquals(checkOnline.getText().trim(), "Offer Automation Translation Online");
		log.info("Online checked - present");
	}
	public void checkVenue() {
		Assert.assertEquals(checkVenue.getText().trim(), "Offer Automation Translation Venue");
		log.info("Venue checked - present");
	}
	public void checkVenueNotListed() {
		Assert.assertEquals(checkVenueNotListed.getText().trim(), "Offer Automation Translation VenueNotListed");
		log.info("VenueNotListed checked - present");
	}
	
	public void clickEditButton1() {
		editButton1.click();
		log.info("editButton1 was clicked");
	}
	public void clickEditButton2() {
		editButton2.click();
		log.info("editButton2 was clicked");
	}
	public void clickeditButton2ForTCNR9655() {
		editButton2ForTCNR9655.click();
		log.info("editButton2 was clicked");
	}
	
	public void clickeditButton3ForTCNR9655() {
		editButton3ForTCNR9655.click();
		log.info("editButton3 was clicked");
	}
	public void clickEditButton3() {
		editButton3.click();
		log.info("editButton3 was clicked");
	}
	public void clickEditButton4() {
		editButton4.click();
		log.info("editButton4 was clicked");
	}
	public void clickEditButton5() {
		editButton5.click();
		log.info("editButton5 was clicked");
	}
	
	public void checkAllNameInResultScreen() {
		this.checkDelivery();
		this.checkMobile();
		this.checkOnline();
		this.checkVenue();
		this.checkVenueNotListed();
	}
	
	
	
	
}
