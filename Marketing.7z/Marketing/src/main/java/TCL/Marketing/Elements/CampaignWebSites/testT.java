package TCL.Marketing.Elements.CampaignWebSites;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class testT {
	public static void main(String[] ferw) {

		System.out.println("Enter values  :");

		String firstString = "teste";

		String secondString = "teae";

		printCommonChars(firstString, secondString);
	}
	private static  void printCommonChars(String string1, String string2) {
		char[] stToCh = string1.replaceAll(" \\s+", " ").toCharArray();

		char[] stToCh2 = string2.replaceAll(" \\s+", " ").toCharArray();

		Set<Character> setString1 = new TreeSet<>();

		Set<Character> setString2 = new TreeSet<>();

		for (char c : stToCh) {
			setString1.add(c);
		}

		for (char c : stToCh2) {
			setString2.add(c);
		}
		setString1.retainAll(setString2);
		System.out.println("Common in alfb order : " + setString1);

		System.out.println("Counter  : " + setString1.size());
	}

}
