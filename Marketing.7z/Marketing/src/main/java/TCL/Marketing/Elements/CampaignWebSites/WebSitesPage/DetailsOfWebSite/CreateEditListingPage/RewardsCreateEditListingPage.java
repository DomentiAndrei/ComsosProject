package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class RewardsCreateEditListingPage extends Boss {
	WebDriver driver;
	Color RGB_COLOUR = Color.fromString("rgb(51, 102, 255)");
	
	@FindBy(xpath  = "//nb-card-body/div[1]/ngx-step-rewards[1]/div[1]/div[2]/div[1]/ngx-tag-chip[1]/button[1]")
    WebElement RewardTranslation;
	
	@FindBy(xpath  = "//nb-card-body/div[1]/ngx-step-rewards[1]/div[1]/div[2]/div[1]/ngx-tag-chip[2]/button[1]")
    WebElement RewardTranslationSecondOne;
	
	//Color HOTPINK = Color.fromString("blue");
	
	@FindBy(xpath = "//nb-card-body/div[1]/ngx-step-rewards[1]/div[1]/div[2]/div[1]/ngx-tag-chip[1]/button[1]")
	WebElement colorFirst;
	
	@FindBy (xpath = "//nb-card-body/div[1]/ngx-step-rewards[1]/div[1]/div[2]/div[1]/ngx-tag-chip[2]/button[1]")
	WebElement colorSecond;
	public RewardsCreateEditListingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void checkAssertRewardTranslation() {
		Assert.assertEquals(RewardTranslation.getText().trim(), "Reward Translation");
		log.info("name for first reward was checked");
	}
	public void checkAssertRewardTranslationSecondOne() {
		Assert.assertEquals(RewardTranslationSecondOne.getText().trim(), "Reward Translation SecondOne");
		log.info("name for second reward was checked");
	}
	public void checkColorForRewardTranslationBlue() {
		String colorCode= colorFirst.getCssValue("background-color"); 
		String expectedColorCodeInRGB= "rgba(51, 102, 255, 1)";
		Assert.assertEquals(colorCode, expectedColorCodeInRGB);
		log.info("Blue color for first Reward was checked ");
	}
	
	public void checkColorForSecondRewardTranslationBlue() {
		String colorCode= colorSecond.getCssValue("background-color"); 
		String expectedColorCodeInRGB= "rgba(51, 102, 255, 1)";
		Assert.assertEquals(colorCode, expectedColorCodeInRGB);
		log.info("Blue color for second Reward was checked ");
	}
	
	
	public void checkColorForRewardTranslationGrayFirst() {
		String colorCode= colorFirst.getCssValue("background-color"); 
		String expectedColorCodeInRGB= "rgba(240, 240, 240, 1)";
		Assert.assertEquals(colorCode, expectedColorCodeInRGB);
		log.info("Blue color for first Reward was checked ");
	}
	
	public void checkColorForRewardTranslationGraySecond() {
		String colorCode= colorSecond.getCssValue("background-color"); 
		String expectedColorCodeInRGB= "rgba(240, 240, 240, 1)";
		Assert.assertEquals(colorCode, expectedColorCodeInRGB);
		log.info("Gray color for first Reward was checked ");
	}
	
	public void clickRewardTranslationFirst() {
		RewardTranslation.click();
		log.info("clicked on first Rewards");
	}
	public void clickRewardTranslationSecondOne() {
		RewardTranslationSecondOne.click();
		log.info("RewardTranslationSecondOne was clicked");
	}
	
	

	
}
