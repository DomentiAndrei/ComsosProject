package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class OfferTypeCreateEditListingPage extends Boss {

	WebDriver driver;
	
	@FindBy(xpath = "//*[contains(text(),' Back to Website')]")
	WebElement backToWebsite;

	@FindBy(xpath = "//p[contains(text(),'Offer Type')]")
	WebElement offerTypeButton;

	@FindBy(xpath = "//p[contains(text(),'Categories')]")
	WebElement categoriesButton;
	
	@FindBy(xpath = "//p[contains(text(),'Location')]")
	WebElement locationButton;
	
	@FindBy(xpath = "//span[contains(text(),'All')]")
	WebElement allCheckBoxOfferType;

	@FindBy(xpath = "//span[contains(text(),'All')]")
	WebElement allCheckBoxCategories;

	@FindBy(xpath = "//nb-card-body//div[2]/div[2]/ngx-list-all[1]/ul[1]/li[2]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tickSubcategoryTranslationSecondTestData;

	@FindBy(xpath = "//nb-card-body/div[1]/ngx-step-categories[1]/div[1]/div[2]/div[3]/div[2]/ngx-list-all[1]/ul[1]/li[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tickSubcategoryTranslationThirdTestData;

	@FindBy(xpath = "//span[contains(text(),'2 for 1')]")
	WebElement twoForOneCheckBox;

	@FindBy(xpath = "//span[contains(text(),'3 for 2')]")
	WebElement threeForTwoCheckBox;

	@FindBy(xpath = "//*[contains(text(),'Free')]")
	WebElement freeCheckBox;
	
	@FindBy(xpath = "//td[contains(text(),'Free')]")
	WebElement freeCheckAssert;

	@FindBy(xpath = "//span[contains(text(),'Discount')]")
	WebElement discountCheckBox;

	@FindBy(xpath = "//span[contains(text(),'X for Y')]")
	WebElement XforYCheckBox;

	@FindBy(xpath = "//button[@type='submit']")
	WebElement nextButton;
	
	@FindBy(xpath = "//button[@status='primary']")
	WebElement nextButtonFromRefineOffers;

	@FindBy(xpath = "//button[@class='appearance-filled size-medium shape-rectangle icon-start status-basic ng-star-inserted nb-transition']")
	WebElement backToEditCriteriaButton;

	@FindBy(xpath = "//a[@class='link ng-star-inserted']")
	WebElement skipToResultButton;

	@FindBy(xpath = "//nb-accordion-item-header[contains(text(),'Reward Translation') and not(contains(text(),'SecondOne'))]")
	WebElement firstListOfResultsForNewListingPot;

	@FindBy(xpath = "//*[contains(text(),' Reward Translation SecondOne')]")
	WebElement secondListOfResultsForNewListingPot;

	@FindBy(xpath = "//nb-accordion-item-header[contains(text(),'Reward Translation ThirdOne') and not(contains(text(),'SecondOne'))]")
	WebElement thirdListOfResultForNewListingPot;

	@FindBy(xpath = "//*[contains(text(),' Reward Translation (1 Offer)')]")
	WebElement RewardTrans;

	@FindBy(xpath = "//*[contains(text(),'Reward Translation SecondOne (1 Offer)')]")
	WebElement RewardTransSecondOne;

	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/ngx-results[1]/div[3]/nb-accordion[1]/nb-accordion-item[1]/nb-accordion-item-header[1]/div[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tICkRewardTranslation; // header tick first 

	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/ngx-results[1]/div[3]/nb-accordion[1]/nb-accordion-item[1]/nb-accordion-item-body[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tICkRewardTranslationName; // after opened reward
	
	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/ngx-results[1]/div[3]/nb-accordion[1]/nb-accordion-item[2]/nb-accordion-item-header[1]/div[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tICkRewardTranslationSecond;// header second

	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/ngx-results[1]/div[3]/nb-accordion[1]/nb-accordion-item[2]/nb-accordion-item-body[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tICkRewardTranslationNameSecond; // after opened second reward -

	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/ngx-results[1]/div[3]/nb-accordion[1]/nb-accordion-item[3]/nb-accordion-item-header[1]/div[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tICkRewardTranslationThird;// header third

	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/ngx-results[1]/div[3]/nb-accordion[1]/nb-accordion-item[3]/nb-accordion-item-header[1]/div[1]/nb-checkbox[1]/label[1]/span[1]")
	WebElement tICkRewardTranslationNameThird; // after opened third reward
	
	@FindBy(xpath = "//p[contains(text(),'Rewards')]")
	WebElement rewardsButton;
	
	@FindBy(xpath = "//p[contains(text(),'Additional')]")
	WebElement additionalButton;
	
	@FindBy(xpath = "//nb-card-body/div[1]/ngx-results[1]/div[1]/span[1]")
	WebElement amountOffersOnResultPot;
	
	@FindBy(xpath = "//div[contains(text(),'Offer Automation Translation ')]")
	WebElement nameofRewords;	
	

	public OfferTypeCreateEditListingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	public void checklNameofRewords(String nameOfCountry) {
		String locator = nameofRewords.getText().toString();
		Assert.assertEquals(locator, "Offer Automation Translation " + nameOfCountry);
	}
	public void clickBackToWebsite() {
		backToWebsite.click();
		log.info("backToWebsite clicked");
	}

	public void clickOfferTypeButton() {
		offerTypeButton.click();
	}

	public void ClickAllCheckBox() { // in offer section
		allCheckBoxOfferType.click();
		log.info("allCheckBox was clicked");
	}

	public void checkAssertionAll() {
		Assert.assertTrue(allCheckBoxOfferType.isEnabled());
		// Assert.assertEquals("Reward Translation (1 Offer)", RewardTrans.getText());
		log.info("First Reward Translation is present");
	}

	public void checkAssertTransSecond() {
		Assert.assertEquals("Reward Translation SecondOne (1 Offer)", RewardTransSecondOne.getText());
	}

	public void checkTICkRewardTrHeaderFirst() {
		boolean checkBoxRewardTranslation = tICkRewardTranslation.isEnabled();
		Assert.assertEquals(true, checkBoxRewardTranslation);
	}

	public void checktICkRewardTranslationNameFirst() {
		boolean checktICkRewaTranslatiName = tICkRewardTranslationName.isEnabled();
		Assert.assertEquals(true, checktICkRewaTranslatiName);
	}
	
	public void checkTICkRewardTranHeaderSecond() {
		boolean tICkRewardTranslationSecondHeder = tICkRewardTranslationSecond.isEnabled();
		Assert.assertEquals(true, tICkRewardTranslationSecondHeder);
	}
	public void clickTICkRewardFirstHeader() {
		tICkRewardTranslation.click();
		log.info("was clicked on first check box");
	}
	public void clickOnCheckBoxOnSecondHeader() {
		tICkRewardTranslationSecond.click();
		log.info("was clicked on second check box");
	}

	public void checkTICkRewardTranslationNameSecond() {
		boolean tICkRewardTranslationNameSecondName = tICkRewardTranslationNameSecond.isEnabled();
		Assert.assertEquals(true, tICkRewardTranslationNameSecondName);
	}

	public void checkTICkRewardTrHeaderThird() {
		boolean checkBoxRewardTranslationThirdHeader = tICkRewardTranslationThird.isEnabled();
		Assert.assertEquals(true, checkBoxRewardTranslationThirdHeader);
	}

	public void checktICkRewardTranslationNameThird() {
		boolean checktICkRewaTranslatiThirdName = tICkRewardTranslationNameThird.isEnabled();
		Assert.assertEquals(true, checktICkRewaTranslatiThirdName);
	}
	public void checkAmountOffersOnResultPot() {
		Assert.assertEquals(amountOffersOnResultPot.getText(), "1 Offers in your Pot");
		log.info("amount Offers OnResultPot checked");
	}

	public void clickFreeCheckBox() {
		freeCheckBox.click();
		log.info("freeCheckBox was clicked");
	}

	public void checkAssertionFree() {
		log.info("here 1");
		Assert.assertFalse(freeCheckAssert.isSelected());
		log.info("displayed POT");
	}

	public void clickTwoToOneBox() {
		twoForOneCheckBox.click();
		log.info("twoForOneCheckBox was clicked");
	}

	public void clickThreeForTwoCheckBox() {
		threeForTwoCheckBox.click();
		log.info("threeForTwoCheckBox was clicked");
	}

	public void clickDiscountCheckBox() {
		discountCheckBox.click();
		log.info("discountCheckBox was clicked");
	}

	public void clickXforYCheckBox() {
		XforYCheckBox.click();
		log.info("XforYCheckBox was clicked");
	}

	public void clickNextButton() {
		nextButton.click();
	}
	public void clicNextButtonFromRefineOffers() {
		nextButtonFromRefineOffers.click();
		log.info("nextButtonFromRefineOffers clicked");
	}

	public void clickBackToEditCriteriaButton() {
		backToEditCriteriaButton.click();
	}

	public void clickAllCheckBoxCategories() {
		allCheckBoxCategories.click();
	}
	public void clickTickSubcategoryTranslationSecondTestData() {
		tickSubcategoryTranslationSecondTestData.click();
		log.info("ticked the second subcategory");
	}

	public void clickTickSubcategoryTranslationThirdTestData() {
		tickSubcategoryTranslationThirdTestData.click();
		log.info("ticked the Third subcategory");
	}

	public void clickSkipToResultButton() {
		skipToResultButton.click();
		log.info("click SkipToResultButton clicked");
	}

	public void clickFirstListOfResultsForNewListingPot() {
		firstListOfResultsForNewListingPot.click();
		log.info("first List Of Result For New Listing Pot was clicked");
	}

	public void clickSecondListOfResultsForNewListingPot() {
		secondListOfResultsForNewListingPot.click();
		log.info("second List Of Result For New Listing Pot was clicked");
	}

	public void clickThirdListOfResultForNewListingPot() {
		thirdListOfResultForNewListingPot.click();
		log.info("third List Of Result For New Listing Pot was clicked");
	}

	public void clickCategoriesButton() {
		categoriesButton.click();
		log.info("Categories button was clicked");
	}
	public void clickLocationButton() {
		locationButton.click();
		log.info("Location Button was clicked");
	}
	public void clickRewardsButton() {
		rewardsButton.click();
		log.info("rewardsButton was clicked");
	}
	public void clickAdditionalButton() {
		additionalButton.click();
		log.info("additionalButton was clicked");
	}
	
	
}
