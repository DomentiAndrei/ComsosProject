package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TCL.Marketing.Boss;

public class WebsitesPage extends Boss {

	WebDriver driver;
	
	@FindBy(xpath = "//button[contains(text(),'Create Website')]")
	WebElement createWebSiteButton;
	
	@FindBy(xpath = "//input[@id='search']")
	WebElement searchField;
	
	@FindBy(xpath = "//button[contains(text(),'Search')]")
	WebElement searchButton;
	
	@FindBy(xpath = "//tbody/tr[1]/td[7]/nb-actions[1]/nb-action[1]")
	WebElement viewButton;
	
	public WebsitesPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void clickCreateWebSiteButton() {
		createWebSiteButton.click();
	}
	public void InsertInSearchField(String searchValue) {
		searchField.sendKeys(searchValue);
	}
	public void clickSearchButton() {
		searchButton.click();
	}
	
	public void clickViewButton() {
		viewButton.click();
		log.info(" 'eye' View button clicked");
	}
	
}
