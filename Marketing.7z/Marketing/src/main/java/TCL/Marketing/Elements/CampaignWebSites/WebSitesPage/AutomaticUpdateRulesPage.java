package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class AutomaticUpdateRulesPage extends Boss {

	WebDriver driver;

	@FindBy(xpath = "//nb-card-body/div[1]/ngx-step-rules[1]/div[1]/div[1]/p[1]")
	WebElement numberOfOffersOnPage;

	public void checkNumberOfOffersOnPage() {
		Assert.assertEquals(numberOfOffersOnPage.getText(), "1 Offers in your Pot");
		log.info("numberOfOffersOnPage checked");
	}

	@FindBy(xpath = "//body[1]//ngx-layout-with-padding[1]//nb-toggle[1]//div[1]")
	WebElement switcher;

	public void checkColorOfSwitcher() {
		String colorCode= switcher.getCssValue("background-color"); 
		String expectedColorCodeInRGB= "rgba(51, 102, 255, 1)";
		Assert.assertEquals(colorCode, expectedColorCodeInRGB);
		log.info("Blue color for switcheron Automatic Update Rules checked ");
	}

	@FindBy(xpath = "//button[contains(text(),'Save Pot')]")
	WebElement savePOTButton;

	@FindBy(xpath = "")
	WebElement categoriesButton;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Delivery')]")
	WebElement delivery;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Mobile')]")
	WebElement mobile;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Online')]")
	WebElement online;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Venue')]")
	WebElement venue;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Venue not listed')]")
	WebElement venueNotListed;

	// ngx-step-rules[1]//button[contains(text(),'Venue') and
	// not(contains(text(),'Venue not listed'))]

	public AutomaticUpdateRulesPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void clickSavePOTButton() {
		savePOTButton.click();
		log.info("Save POT button was clicked");
	}

	public void checkDelivery() {
		Assert.assertEquals(delivery.getText().trim(), "DELIVERY");
		log.info("Delivery checked - present in Automatic Update Rules");
	}

	public void checkMobile() {
		Assert.assertEquals(mobile.getText(), "MOBILE");
		log.info("Mobile checked - present in Automatic Update Rules");
	}

	public void checkOnline() {
		Assert.assertEquals(online.getText(), "ONLINE");
		log.info("Online checked - present in Automatic Update Rules");
	}

	public void checkVenue() {
		String venueValue = "venue";
		Assert.assertEquals(venue.getText(), venueValue.toUpperCase());
		log.info("Venue checked - present in Automatic Update Rules");

	}

	public void checkVenueNotListed() {
		Assert.assertEquals(venueNotListed.getText(), "VENUE NOT LISTED");
		log.info("VenueNotListed checked - present in Automatic Update Rules");
	}

	public void checkAllNameInAutomaticUpdateRulesPage() throws InterruptedException {

		this.checkDelivery();
		this.checkMobile();
		this.checkOnline();
		this.checkVenue();
		// this.checkVenueNotListed();

	}

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Bespoke')]")
	WebElement Bespoke;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Generic')]")
	WebElement Generic;

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Rewards for All')]")
	WebElement RFA;

	public void checkBespoke() {
		Assert.assertEquals(Bespoke.getText().trim(), "BESPOKE");
		log.info("Bespoke checked - present in Automatic Update Rules");
	}

	public void checkGeneric() {
		Assert.assertEquals(Generic.getText().trim(), "GENERIC");
		log.info("Generic checked - present in Automatic Update Rules");
	}

	public void checkRFA() {
		Assert.assertEquals(RFA.getText().trim(), "REWARDS FOR ALL");
		log.info("RFA checked - present in Automatic Update Rules");
	}

	public void checkAllCompaignRestric() {
		this.checkBespoke();
		this.checkGeneric();
		this.checkRFA();
	}

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'0') or (contains(text(),'1500'))]")
	WebElement backEndCost;

	public void checkBackEndCostZero() {
		Assert.assertEquals(backEndCost.getText(), "0");
		log.info("backEndCost checked");
	}

	public void checkBackEndCost1500() {
		Assert.assertEquals(backEndCost.getText(), "1500");
		log.info("backEndCost checked");
	}

	public void checkBackEndCost9999() {
		Assert.assertEquals(backEndCost.getText(), "9999");
		log.info("backEndCost checked");
	}

	// RRP
	@FindBy(xpath = "//nb-card-body//div[6]/div[2]/div[1]/span[1]/button[1]")
	WebElement RRPZero;
	
	@FindBy(xpath = "//button[contains(text(),'5000')]")
	WebElement RRPMin;
	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'9999.99')]")
	WebElement RRPMax;

	public void checkRRPZero() {
		Assert.assertEquals(RRPZero.getText(), "0");
		log.info("RRPZero checked");
	}
	public void checkRRPMin() {
		Assert.assertEquals(RRPMin.getText(), "5000");
		log.info("RRPMin checked");
	}

	public void checkRRPMax() {
		Assert.assertEquals(RRPMax.getText(), "9999.99");
		log.info("RRPMax checked");
	}

	// Rewards

	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Reward Translation')]")
	WebElement rewardTranslation;

	public void checkRewardTranslation() {
		Assert.assertEquals(rewardTranslation.getText(), "REWARD TRANSLATION");
		log.info("Reward Translation checked");
	}

	// Offer Types
	@FindBy(xpath = "//ngx-step-rules[1]//button[contains(text(),'Discount')]")
	WebElement discount;

	public void checkDiscount() {
		Assert.assertEquals(discount.getText(), "DISCOUNT");
		log.info("Discount checked");
	}

}
