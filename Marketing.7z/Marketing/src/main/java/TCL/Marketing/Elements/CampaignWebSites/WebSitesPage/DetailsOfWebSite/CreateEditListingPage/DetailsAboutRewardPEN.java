package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite.CreateEditListingPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class DetailsAboutRewardPEN extends Boss {

	WebDriver driver;
	// --- Location ---
	@FindBy(xpath = "//button[contains(text(),'Delivery')]")
	WebElement delivery;
	@FindBy(xpath = "//button[contains(text(),'Mobile')]")
	WebElement mobile;
	@FindBy(xpath = "//button[contains(text(),'Online')]")
	WebElement online;
	@FindBy(xpath = "//button[contains(text(),'Venue') and not(contains(text(),'Venue not listed'))]")
	WebElement venue;
	@FindBy(xpath = "//button[contains(text(),'Venue not listed')]")
	WebElement venueNotListed;

	@FindBy(xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[3]/nb-card[1]/nb-card-body[1]/div[1]/div[1]/button[1]")
	WebElement closeButton;

	public DetailsAboutRewardPEN(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void checkDelivery() {
		Assert.assertEquals(delivery.getText().trim(), "Delivery");
		log.info("Delivery checked - present in DetailsAboutRewardPEN");
	}

	public void checkMobile() {
		Assert.assertEquals(mobile.getText().trim(), "Mobile");
		log.info("Mobile checked - present in DetailsAboutRewardPEN");
	}

	public void checkOnline() {
		Assert.assertEquals(online.getText().trim(), "Online");
		log.info("Online checked - present in DetailsAboutRewardPEN");
	}

	public void checkVenue() {
		Assert.assertEquals(venue.getText().trim(), "Venue");
		log.info("Venue checked - present in DetailsAboutRewardPEN");
	}

	public void checkVenueNotListed() {
		Assert.assertEquals(venueNotListed.getText().trim(), "Venue not listed");
		log.info("VenueNotListed checked - present in DetailsAboutRewardPEN");
	}

	public void clickCloseButton() {
		closeButton.click();
		log.info("closeButton clicked");
	}
	// --- Additional --

	@FindBy(xpath = "//button[contains(text(),'Bespoke ')]")
	WebElement Bespoke;

	@FindBy(xpath = "//button[contains(text(),' Generic ')]")
	WebElement Generic;

	@FindBy(xpath = "//button[contains(text(),'RFA')]")
	WebElement RFA;

	public void checkBespoke() {
		Assert.assertEquals(Bespoke.getText().trim(), "Bespoke");
		log.info("Bespoke checked - present in DetailsAboutRewardPEN");
	}

	public void checkGeneric() {
		Assert.assertEquals(Generic.getText().trim(), "Generic");
		log.info("Generic checked - present in DetailsAboutRewardPEN");
	}

	public void checkRFA() {
		Assert.assertEquals(RFA.getText().trim(), "RFA");
		log.info("RFA checked - present in DetailsAboutRewardPEN");
	}
	/// Back end Cost

	@FindBy(xpath = "//button[contains(text(),'0 GBP')]")
	WebElement BackEndCostZero;
	@FindBy(xpath = "//button[contains(text(),'1500 GBP')]")
	WebElement BackEndCost1500;
	@FindBy(xpath = "//button[contains(text(),'9999.99 GBP')]")
	WebElement BackEndCost9999;

	public void checkBackEndCostZero() {
		Assert.assertEquals(BackEndCostZero.getText(), "0 GBP");
		log.info("BackEndCost checked after click on edit 'PEN' button zero  ");
	}

	public void checkBackEndCost1500() {
		Assert.assertEquals(BackEndCost1500.getText(), "1500 GBP");
		log.info("BackEndCost checked after click on edit 'PEN' button 1500  ");
	}

	public void checkBackEndCost9999() {
		Assert.assertEquals(BackEndCost9999.getText(), "9999.99 GBP");
		log.info("BackEndCost checked after click on edit 'PEN' button 9999.99  ");
	}

	/// Recommended Retail Price
	
	//nb-card-body/div[1]//div[3]/button[1]
	
	@FindBy(xpath = "//nb-card-body/div[1]//div[3]/button[1]")
	WebElement RRPZero;
	@FindBy(xpath = "//nb-card-body/div[1]//div[3]/button[1]")
	WebElement RRP1500;
	@FindBy(xpath = "//nb-card-body/div[1]//div[3]/button[1]")
	WebElement RRP9999;
	
	public void checkRRPZero() {
		Assert.assertEquals(RRPZero.getText(), "0 GBP");
		log.info("RRP checked after click on edit 'PEN' button zero  ");
	}

	public void checkRRP1500() {
		Assert.assertEquals(RRP1500.getText(), "1500 GBP");
		log.info("RRP checked after click on edit 'PEN' button 1500  ");
	}

	public void checkRRP9999() {
		Assert.assertEquals(RRP9999.getText(), "9999.99 GBP");
		log.info("RRP checked after click on edit 'PEN' button 9999.99  ");
	}
	
	

}
