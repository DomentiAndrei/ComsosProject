package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.DetailsOfWebSite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class DetailsOfWebsitePage extends Boss {

	WebDriver driver;
	
	@FindBy(xpath  = "//a[contains(text(),'Add Rewards ')]")
    WebElement addRewards ;
	
	@FindBy(xpath ="//body[1]//nb-card-body[1]/div[2]/div[2]/nb-card[1]/nb-card-body[1]/div[3]/a[1]")
	WebElement addRewardsPlusButtonFirst;
	
	@FindBy(xpath ="//body[1]//nb-card-body[1]/div[2]/div[2]/nb-card[1]/nb-card-body[1]/div[4]/a[1]")
	WebElement addRewardsPlusButtonSecond;

	@FindBy(xpath = "//a[contains(text(),' Edit Listing ')]")
	WebElement editButton;
	
	@FindBy(xpath = "//body[1]//div[2]//div[2]/nb-card[1]//div[2]/div[1]/div[1]")
	WebElement amountOfOffers;
	@FindBy(xpath = "//body[1]//div[2]//div[2]/nb-card[1]//div[2]/div[2]/div[1]")
	WebElement amountOfPartners;
	@FindBy(xpath = "//body[1]//div[2]//div[2]/nb-card[1]//div[2]/div[3]/div[1]")
	WebElement amountOfRewards;
	@FindBy(xpath = "//body[1]//div[2]//div[2]/nb-card[1]//div[2]/div[4]/div[1]")
	WebElement amountOfLocations;
	
	public DetailsOfWebsitePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void clickAddRewardsbutton() {
		addRewards.click();
		log.info("addRewards clicked");
	}

		
	
	public void clickAddRewardsPlusButtonFirst() {
		addRewardsPlusButtonFirst.click();
		log.info("addRewardsPlusButtonFirst clicked");
	}
	public void clickaddRewardsPlusButtonSecond() {
		addRewardsPlusButtonSecond.click();
		log.info("addRewardsPlusButtonSecond clicked");
	}
	public void clickEditButton() {
		editButton.click();
		log.info("EditButton clicked");
	}
	public void checkAmountOfOffers(String amountOffers) {
		Assert.assertEquals(amountOfOffers.getText(), amountOffers);
		log.info("amountOffers checked");
	}
	public void checkAmountOfPartners(String amountPartners) {
		Assert.assertEquals(amountOfPartners.getText(), amountPartners);
		log.info("amountPartners checked");
	}
	public void checkAmountOfRewards(String amountRewards) {
		Assert.assertEquals(amountOfRewards.getText(), amountRewards);
		log.info("amountRewards checked");
	}
	public void checkAmountOfLocations(String amountLocations) {
		Assert.assertEquals(amountOfLocations.getText(), amountLocations );
		log.info("amountLocations checked");
	}
	
	
}
