package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.ResultsElements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ResultListingPOT {

	
WebDriver driver;
	
	@FindBy(xpath  = "//td[contains(text(),'Free')]")
    WebElement FreeOfferType ;
	
	@FindBy(xpath  = "//td[contains(text(),'Discount')]")
    WebElement DiscauntOfferType ;
	
	@FindBy(xpath  = "//tbody/tr[3]/td[3]")
    WebElement ThreeForTwoOfferType ;
	
	@FindBy(xpath  = "//tbody/tr[4]/td[3]")
    WebElement TwoForOneOfferType ;
	
	@FindBy(xpath  = "//tbody/tr[5]/td[3]")
    WebElement FiveForThreeOfferType;
	
	@FindBy (xpath = "//div[contains(text(),'Offer TwoForOne Automation Translation')]")
	WebElement OfferTwoForOneAutomationTranslation;

	@FindBy (xpath = "//div[contains(text(),'Offer ThreeForTwo Automation Translation')]")
	WebElement OfferThreeForTwoAutomationTranslation;
	
	@FindBy (xpath = "//div[contains(text(),'Offer FiveForThree Automation Translation')]")
	WebElement OfferFiveForThreeAutomationTranslation;
	
	@FindBy (xpath = "//div[contains(text(),'Offer Automation Translation SecondOne')]")
	WebElement OfferAutomationTranslationSecondOne;
	
	@FindBy (xpath = "//nb-accordion-item-header[contains(text(),' Reward Translation (5 Offers)')]")
	WebElement AmountOfOffers;
	
	@FindBy (xpath = "//body[1]/ngx-app[1]/ngx-pages[1]/ngx-one-column-layout[1]/nb-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/nb-layout-column[1]/ngx-layout-with-padding[1]/ngx-by-rewards[1]/div[2]/div[1]/nb-card[1]/nb-card-body[1]/div[1]/div[1]/button[2]")
	WebElement nextButton;
	public ResultListingPOT(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	
	public void resultFreeOfferType() {
		Assert.assertEquals("Free", FreeOfferType.getText());
	}
	public void resultDiscauntOfferType() {
		Assert.assertEquals("Discount", DiscauntOfferType.getText());
	}
		
	public void resultOfferTwoForOneAutomationTranslation() {
		Assert.assertEquals("Offer TwoForOne Automation Translation", OfferTwoForOneAutomationTranslation.getText());
	}
	public void resultOfferThreeForTwoAutomationTranslation() {
		Assert.assertEquals("Offer ThreeForTwo Automation Translation", OfferThreeForTwoAutomationTranslation.getText());
	}
	public void resultOfferFiveForThreeAutomationTranslation() {
		Assert.assertEquals("Offer FiveForThree Automation Translation", OfferFiveForThreeAutomationTranslation.getText());
	}
	public void resultOfferAutomationTranslationSecondOne() {
		Assert.assertEquals("Offer Automation Translation SecondOne", OfferAutomationTranslationSecondOne.getText());
	}
	public void amountOfOffersFive() {
		Assert.assertEquals("Reward Translation (5 Offers)", AmountOfOffers.getText());
	}
	public void clickNextButton() {
		nextButton.click();
	}
	
	public void CheckAllAsserts() {
		this.resultFreeOfferType();
		this.resultDiscauntOfferType();
		this.resultOfferTwoForOneAutomationTranslation();
		this.resultOfferThreeForTwoAutomationTranslation();
		this.resultOfferFiveForThreeAutomationTranslation();
		this.amountOfOffersFive();
	}
	public void checkForXToY() {
		this.resultOfferTwoForOneAutomationTranslation();
		this.resultOfferThreeForTwoAutomationTranslation();
		this.resultOfferFiveForThreeAutomationTranslation();
	}
	
	
	
}
