package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TCL.Marketing.Boss;

public class CreateYourWebSiteListingPage extends Boss{


	WebDriver driver;
	
	@FindBy(xpath  = "//h6[contains(text(),'Update by Rewards')]")
    WebElement updateByRewards ;
	
	@FindBy(xpath  = "//h6[contains(text(),'Update by Tags')]")
    WebElement updateByTab ;
	
	public CreateYourWebSiteListingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void ClickUpdateByRewards() {
		updateByRewards.click();
		log.info("Update by Rewards clicked");
	}
	public void ClickUpdateByTab() {
		updateByTab.click();
	}
	
}
