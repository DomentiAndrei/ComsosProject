package TCL.Marketing.Elements.CampaignWebSites.WebSitesPage.CriteriaEditRewards;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import TCL.Marketing.Boss;

public class AdditionalPage extends Boss {

	WebDriver driver;

	@FindBy(xpath = "//span[contains(text(),'All')]")
	WebElement allCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Bespoke')]")
	WebElement bespokeCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Generic')]")
	WebElement genericCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Rewards for All')]")
	WebElement rewardsForAllCheckBox;

	@FindBy(xpath = "//nb-card-body/div[1]/ngx-additional-step[1]/div[4]/div[1]/ngx-slider[1]//span[9][contains(text(),'0')]")
	WebElement zeroOnSlaider;
	// span[9][contains(text(),'0')]

	@FindBy(xpath = "//ngx-additional-step[1]//input[@type='number']")
	WebElement additionalNumber;
	// RRP
	@FindBy(xpath = "//input[@name='min-rrp']")
	WebElement minRRP;

	@FindBy(xpath = "//input[@name='max-rrp']")
	WebElement maxRRP;
	
	@FindBy (xpath = "//p[contains(text(),'RRP Min must be smaller or equal to RRP Max.')]")
	WebElement validationMessageOfRRP;

	public AdditionalPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void checkAllCheckBox() {
		boolean tICkAllCheckBox = allCheckBox.isEnabled();
		Assert.assertEquals(true, tICkAllCheckBox);
		log.info("Additional ALL checkbox checked");
	}

	public void checkTickBespokeCheckBox() {
		boolean tickBespokeCheckBox = bespokeCheckBox.isEnabled();
		Assert.assertEquals(true, tickBespokeCheckBox);
		log.info("Additional bespoke checkbox checked");
	}

	public void checkTicGenericCheckBox() {
		boolean tickGenericCheckBox = genericCheckBox.isEnabled();
		Assert.assertEquals(true, tickGenericCheckBox);
		log.info("Additional generic checkbox checked");
	}

	public void checkTicRewardsForAllCheckBox() {
		boolean tickRewardsForAllCheckBox = rewardsForAllCheckBox.isEnabled();
		Assert.assertEquals(true, tickRewardsForAllCheckBox);
		log.info("Additional RewardsForAll checkbox checked");
	}

	public void checkZeroOnSlaider() {
		Assert.assertEquals(zeroOnSlaider.getText(), "0");
		log.info("zeroOnSlaider was checked");
	}

	public void checkAdditionalNumber() {
		Assert.assertEquals(additionalNumber.getText(), 0);
		log.info("zeroOnSlaider was checked in additional number");
	}

	public void chekcValidationMessageOFRRP() {
		Assert.assertEquals("RRP Min must be smaller or equal to RRP Max.", validationMessageOfRRP.getText());
		log.info("validationMessageOfRRP checked");
	}
	public void insertAdditionalNumber(String additionalNumberField) {
		// additionalNumber.clear();
		additionalNumber.sendKeys(additionalNumberField);
	}

	public void insertMinRRP(String minRRPValue) {
		minRRP.clear();
		minRRP.sendKeys(minRRPValue);
		log.info("minRRPValue inserted");
	}
	public void insertMaxRRP(String maxRRPValue) {
		maxRRP.clear();
		maxRRP.sendKeys(maxRRPValue);
		log.info("maxRRPValue inserted");
	}

	public void clickAllCheckBox() {
		allCheckBox.click();
		log.info("allCheckBox additional clicked");
	}

	public void clickBespokeCheckBox() {
		bespokeCheckBox.click();
		log.info("bespokeCheckBox additional clicked");
	}

	public void clickGenericCheckBox() {
		genericCheckBox.click();
		log.info("genericCheckBox additional clicked");
	}

	public void clickRewardsForAllCheckBox() {
		rewardsForAllCheckBox.click();
		log.info("rewardsForAllCheckBox additional clicked");
	}

	public void checkAllCheckBoxes() {
		this.checkAllCheckBox();
		this.checkTickBespokeCheckBox();
		this.checkTicGenericCheckBox();
		this.checkTicRewardsForAllCheckBox();
	}

}
