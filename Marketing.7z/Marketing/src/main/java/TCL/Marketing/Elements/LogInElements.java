package TCL.Marketing.Elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TCL.Marketing.Boss;

public class LogInElements extends Boss {

	WebDriver driver;
	@FindBy(xpath = "//input[@type='email']")
	WebElement email;

	@FindBy(xpath = "//input[@type='submit']")
	WebElement next;

	@FindBy(xpath = "//input[@type='password']")
	WebElement password;

	@FindBy(xpath = "//input[@type='submit']")
	WebElement enter;

	
	@FindBy(xpath = "//input[@id='idBtn_Back']")
	WebElement no;
	
	@FindBy(xpath = "//h3[contains(text(),'Welcome back, !')]")
	WebElement welcomeMessage;

	// --------------------
	public LogInElements(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// --------------------
	public void emailField(String emailAddress) {
		email.sendKeys(emailAddress);
	}

	public void nextButton() {
		next.click();
	}

	public void passwordField(String passwordData) {
		password.sendKeys(passwordData);
	}

	public void enterButton() {
		enter.click();
	}

	public void exitFromSystemNO() {
		no.click();
	}

	public String checkMessage() {
		return welcomeMessage.getText();
	}

	public void logInAutoTest(String emailAddress, String passwordData) throws InterruptedException {
		
		this.emailField(emailAddress);
		log.info("email inserted");
		this.nextButton();
		this.passwordField(passwordData);
		log.info("password inserted");
		Thread.sleep(2000);
		this.enterButton();
		this.exitFromSystemNO();
	}

}
